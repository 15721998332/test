<?php

require_once(__DIR__ . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'qcloud' . DIRECTORY_SEPARATOR . 'cos' . DIRECTORY_SEPARATOR . 'Auth.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'qcloud' . DIRECTORY_SEPARATOR . 'cos' . DIRECTORY_SEPARATOR . 'Helper.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'qcloud' . DIRECTORY_SEPARATOR . 'cos' . DIRECTORY_SEPARATOR . 'HttpClient.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'qcloud' . DIRECTORY_SEPARATOR . 'cos' . DIRECTORY_SEPARATOR . 'Api.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'qcloud' . DIRECTORY_SEPARATOR . 'cos' . DIRECTORY_SEPARATOR . 'HttpRequest.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'qcloud' . DIRECTORY_SEPARATOR . 'cos' . DIRECTORY_SEPARATOR . 'HttpResponse.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'qcloud' . DIRECTORY_SEPARATOR . 'cos' . DIRECTORY_SEPARATOR . 'LibcurlWrapper.php');
require_once(__DIR__ . DIRECTORY_SEPARATOR . 'src' . DIRECTORY_SEPARATOR . 'qcloud' . DIRECTORY_SEPARATOR . 'cos' . DIRECTORY_SEPARATOR . 'SliceUploading.php');
