<?php
namespace Common\Lib\WeiXin;

use Common\Lib\HttpUtil;
use Common\Lib\SysCacheMgr;
use Common\Lib\WeiXin\Lib\ErrorCode;
use Common\Lib\WeiXin\Lib\Prpcrypt;
use Common\Lib\WeiXin\Lib\SHA1;
use Common\Lib\WeiXin\Lib\XMLParse;
use Common\Lib\WeiXin\Lib\WXBizMsgCrypt;
use Common\Lib\FuncUtils\ImageFuncUtil;
use Common\Lib\UploadImgUtil;

/**
 * 微信接口开发的SDK.
 *
 * @copyright Copyright (c) 1998-2014 Tencent Inc.
 */

/**
 * 1.getAccessToken				获取AccessToken；
 * 2.sendTransToCustomServiceMessage	转发给客服接管
 * 2.sendTextMessage			发送文本信息
 * 3.sendNewsMessage			发送图文消息
 * 4.getAuthorizeCode			获取网页授权读取用户openid
 * 5.getJsApiTicket				生成微信JS接口的临时票据
 * 6.getUserInfo				获取微信用户信息
 * 7.createQrcodeFixTicket		创建一个固定的二维码
 * 8.uploadImg					上传一个图片
 * 9.createCard					创建卡券
 * 10.getCardSign				得到卡签名
 * 11.getApiTicket				生成微信api接口的临时票据
 * 12.getCacheData				读取缓存数据()
 * 13.setCacheData				设置缓存数据()
 * 14.sendTemplateMessage		发送模板消息
 * 15.verifyURL					验证URL
 * 16.encryptMsg				将公众平台回复用户的消息加密打包
 * 17.decryptMsg				检验消息的真实性，并且获取解密后的明文
 * 18.downloadTemplate			下载消息模板
 * 
 * 25.sendCustomerServiceMsg	发送客户服务回复消息
 */
class WXSdk
{
	private $m_compid;				//用于标识公司号的唯一ID，位于URL的company参数中，暂时是Md5(公司代码)的值
	private $m_sToken;				//微信对接token
	private $m_sEncodingAesKey;		//微信对接验证的key值secretkey
	private $m_appid;				//微信对接的公众号开发ID
	private $m_appsecret;			//微信对接的开发密accesstoken
	private $m_cropid;				//微信公众号的原始ID
	private $m_comp_id;				//公司的id与md5有别
	private $wxthirdauth;			//是否使用第三方授权
	private $wxthirdastatus;		//第三方授权状态
	private $msgcrypt;				//是否加密
	private $m_setup_id;			//公众号ID
	
	/**
	 * 构造函数
	 * 从配置文件中读取微信相关设置属性
	 */
	function __construct()
	{
// 		$company = SysCacheMgr::getcompanybyweixinid($compmd5id);
// 		$this->m_sToken = $company["mp_token"];
// 		$this->m_sEncodingAesKey = $company["mp_encodingaeskey"];
// 		$this->m_appid = $company["mp_appid"];
// 		$this->m_cropid = $company["mp_cropid"];
// 		$this->m_appsecret = $company["mp_appsecret"];
// 		$this->m_compid = $compmd5id;
// 		$this->m_comp_id = $company["comp_id"];
// 		$this->wxthirdauth = $company["wxthirdauth"];
// 		$this->wxthirdastatus = $company["wxthirdastatus"];
// 		$this->msgcrypt = $company["msgcrypt"];
// 		$this->m_setup_id = $company["setup_id"];
		$company=M('weixin_setup')->where(array('setup_id'=>1))->find();
		$this->m_appid = $company["mp_appid"];
		$this->m_appsecret = $company["mp_appsecret"];
	}

	/**
	 * @return the $m_sToken
	 */
	public function getM_sToken() {
		return $this->m_sToken;
	}

	/**
	 * @return the $m_sEncodingAesKey
	 */
	public function getM_sEncodingAesKey() {
		return  $this->m_sEncodingAesKey;
	}

	/**
	 * @return the $m_appid
	 */
	public function getM_appid() {
		return $this->m_appid;
	}

	/**
	 * @return the $m_appsecret
	 */
	public function getM_appsecret() {
		return $this->m_appsecret;
	}

	/**
	 * @return the $m_cropid
	 */
	public function getM_cropid() {
		return $this->m_cropid;
	}
	
	/**
	 * @return the $m_setup_id
	 */
	public function getM_seupid() {
		return $this->m_setup_id;
	}
	
	/**
	 * 获取AccessToken,根据失效时间暂存起来,兼容第三方授权，如果为第三方授权，则采用app_auth_token【authorizer_access_token】
	 * 由于当AccessToken缓存失效时，并发的多个连接将会是时访问，可能刷新了几个不同的AccessToken，从而可能出现后刷新的AccessToken被其它链接刷失效
	 * 解决并发的方法：
	 * 1、缓存AccessToken的同时，按返回的失效时间备份缓存另外一份AccessToken；
	 * 2、在任何一个进程调用函数刷新AccessToken时，在缓存中记录已开启刷新的标识，该标识10秒后自动失效；
	 * 3、刷新标识在生效时，从备份缓存中读取AccessToken使用；
	 * @param String $accessToken
	 * @param String $sErrmsg
	 * @return 0 成功，非0失败
	 */
	public function getAccessToken(&$accessToken,&$sErrmsg)
	{
		if($this->wxthirdauth=='Y' && $this->wxthirdastatus=='Y')
		{
			$authtoken = M('authtoken')->field('auth_app_id,app_auth_token,app_refresh_token,expires_date')->where(array('comp_id'=>$this->m_comp_id,'auth_app_id'=>$this->getM_appid()))->find();
			if(empty($authtoken)){
				$sErrmsg = '读取token失败';
				return 1;
			}else{
				$accessToken = $authtoken['app_auth_token'];
				return  0;
			}
		}
		
		
		$token = M("weixin_token")->field('tokenvalue,expiredate,lastdate,errmsg')->where(array('appid'=>$this->getM_appid(),'tokentype'=>'accesstoken'))->find();
		if(empty($token)){
			$sErrmsg = '读取token失败';
			return 1;
		}else{
			$accessToken = $token['tokenvalue'];
			return  0;
		} 

	}

	
	/**
	 * 转发客服接管消息
	 * @param string $toUserOpenid	用户openid
	 * @param string $msgsource	消息来源  public公众号,third第三方平台
	 * @param string $sErrmsg	引用参数错误信息
	 * @return
	 */
	public function sendTransToCustomServiceMessage($toUserOpenid,$msgsource,&$sErrmsg)
	{
		$data = "<xml>
		<ToUserName><![CDATA[".$toUserOpenid."]]></ToUserName>
		<FromUserName><![CDATA[".$this->getM_cropid()."]]></FromUserName>
		<CreateTime>".time()."</CreateTime>
		<MsgType><![CDATA[transfer_customer_service]]></MsgType>
		</xml>";
	
		//微信测试用例消息
		$timestamp = time();
		$prpcrypt = new Prpcrypt();
		$sOnceStr = $prpcrypt->getRandomStr();
		if (strtolower($msgsource) == "third")
		{
			$wxcpt = new WXBizMsgCrypt(SysCacheMgr::getSysEnum('WX3RD_TOKEN'), SysCacheMgr::getSysEnum('WX3RD_ENCODEKEY'), SysCacheMgr::getSysEnum('WX3RD_APPID'));
			$errCode = $wxcpt->EncryptMsg($data, time(), $sOnceStr, $data);
		}
		else if (strtolower($msgsource) == "public" && $this->msgcrypt == "Y")
		{
			$wxcpt = new WXBizMsgCrypt($this->m_sToken,$this->m_sEncodingAesKey,$this->m_appid);
			$errCode = $wxcpt->EncryptMsg($data, time(), $sOnceStr, $data);
		}
	
		return $data;
	}	
	/**
	 * 被动回复文本消息
	 * @param string $toUserOpenid	用户openid
	 * @param string $content	文本内容
	 * @param string $msgsource	消息来源  public公众号,third第三方平台
	 * @param string $sErrmsg	引用参数错误信息
	 * @return
	 */
	public function sendTextMessage($toUserOpenid,$content,$msgsource,&$sErrmsg)
	{
		$data = "<xml>
		<ToUserName><![CDATA[".$toUserOpenid."]]></ToUserName>
		<FromUserName><![CDATA[".$this->getM_cropid()."]]></FromUserName>
		<CreateTime>".time()."</CreateTime>
		<MsgType><![CDATA[text]]></MsgType>
		<Content><![CDATA[".$content."]]></Content>
		</xml>";
		
		//微信测试用例消息
		$timestamp = time();
		$prpcrypt = new Prpcrypt();
		$sOnceStr = $prpcrypt->getRandomStr();
		if (strtolower($msgsource) == "third")
		{
			$wxcpt = new WXBizMsgCrypt(SysCacheMgr::getSysEnum('WX3RD_TOKEN'), SysCacheMgr::getSysEnum('WX3RD_ENCODEKEY'), SysCacheMgr::getSysEnum('WX3RD_APPID'));
			$errCode = $wxcpt->EncryptMsg($data, time(), $sOnceStr, $data);
		}
		else if (strtolower($msgsource) == "public" && $this->msgcrypt == "Y")
		{
			$wxcpt = new WXBizMsgCrypt($this->m_sToken,$this->m_sEncodingAesKey,$this->m_appid);
			$errCode = $wxcpt->EncryptMsg($data, time(), $sOnceStr, $data);
		}
		
		return $data;
	}
	
	/**
	 * 被动回复图文消息
	 * @param string $toUserOpenid	用户openid
	 * @param string $content	文本内容
	 * @param string $msgsource	消息来源  public公众号,third第三方平台
	 * @param string $sErrmsg	引用参数错误信息
	 * @return
	 */
	public function sendNewTextMessage($toUserOpenid,$content,$msgsource,&$sErrmsg)
	{
		$data = "<xml>
		<ToUserName><![CDATA[".$toUserOpenid."]]></ToUserName>
		<FromUserName><![CDATA[".$this->getM_cropid()."]]></FromUserName>
		<CreateTime>".time()."</CreateTime>
		<MsgType><![CDATA[news]]></MsgType>
		<ArticleCount>1</ArticleCount>
		<Articles>
		<item>
		<Title><![CDATA[".$content[0]['title']."]]></Title> 
		<Description><![CDATA[".$content[0]['digest']."]]></Description>
		<PicUrl><![CDATA[".$content[0]['thumb_url']."]]></PicUrl>
		<Url><![CDATA[".$content[0]['url']."]]></Url>
		</item>
		</Articles>
		</xml>";
	
		//微信测试用例消息
		$timestamp = time();
		$prpcrypt = new Prpcrypt();
		$sOnceStr = $prpcrypt->getRandomStr();
		if (strtolower($msgsource) == "third")
		{
			$wxcpt = new WXBizMsgCrypt(SysCacheMgr::getSysEnum('WX3RD_TOKEN'), SysCacheMgr::getSysEnum('WX3RD_ENCODEKEY'), SysCacheMgr::getSysEnum('WX3RD_APPID'));
			$errCode = $wxcpt->EncryptMsg($data, time(), $sOnceStr, $data);
		}
		else if (strtolower($msgsource) == "public" && $this->msgcrypt == "Y")
		{
			$wxcpt = new WXBizMsgCrypt($this->m_sToken,$this->m_sEncodingAesKey,$this->m_appid);
			$errCode = $wxcpt->EncryptMsg($data, time(), $sOnceStr, $data);
		}
	
		return $data;
	}

	/**
	 * 主动发送消息接口
	 * @param string $data		消息数据
	 * @param string $sErrmsg	引用参数返回错误信息
	 * @return 0表示成功 	非0表示失败
	 */
	public function sendNewsMessage($data,&$sErrmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0)
		{
			return $ret;
		}
		//转换为json,并且不能转为unicode
		$data = json_encode($data,JSON_UNESCAPED_UNICODE);
		//调用发送接口
		$jsondata = HttpUtil::https_post("https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=".$saccessToken,$data);
		$retobj = json_decode($jsondata,true);
		if ($retobj["errcode"] != "0")
		{
			$sErrmsg = $retobj["errmsg"];
			
			p_file('wxsdk发送sendNewsMessage失败:');
			p_file('失败明细:'.$jsondata);
			
			return $retobj["errcode"];
		}
		if(empty($retobj)){
			$sErrmsg = '网络异常sendNewsMessage';
			return 1;
		}
		return 0;
	}

	/**
	 * 通用发送消息接功能,实现所有消息发送的统一调用
	 * @param array	$data			待发送的数据
	 * @param String $sErrMsg		引用参数返回错误信息
	 * @return 0表示成功 	非0表示失败
	 */
	public function sendMessage($data,&$sErrmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0)
		{
			return $ret;
		}
		//转换为json,并且不能转为unicode
		$data = json_encode($data,JSON_UNESCAPED_UNICODE);
		//调用发送接口
		$jsondata = HttpUtil::https_post("https://api.weixin.qq.com/cgi-bin/message/mass/send?access_token=".$saccessToken,$data);
		$retobj = json_decode($jsondata,true);
		if ($retobj["errcode"] != "0")
		{
			$sErrmsg = $retobj["errmsg"];
			
			p_file('wxsdk发送sendMessage失败:');
			p_file('失败明细:'.$jsondata);
			
			return $retobj["errcode"];
		}
		if(empty($retobj)){
			$sErrmsg = '网络异常sendMessage';
			return 1;
		}
		return 0;
	}

	/**
	 * 生成微信JS接口的临时票据
	 * @param string $jsApiTicket
	 * @param string $sErrmsg
	 * @return 0 成功，非0失败
	 */
	public function getJsApiTicket(&$jsApiTicket,&$sErrmsg)
	{
		return $this->getTicket("Mp_JsApiTicket", $jsApiTicket, $sErrmsg);
	}

	/**
	 * 生成微信api接口的临时票据
	 * @param string $jsApiTicket
	 * @param string $sErrmsg
	 * @return 0 成功，非0失败
	 */
	public function getApiTicket(&$apiTicket,&$sErrmsg)
	{
		return $this->getTicket("Mp_ApiTicket", $apiTicket, $sErrmsg);
	}
	
	
	/**
	 * 生成签名串
	 *
	 */
	public function getSignPackage() 
	{
		$jsapiTicket="";
		$errmsg="";
		$ret = $this->getJsApiTicket($jsapiTicket,$errmsg);
		
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		
		$timestamp = time();
		$nonceStr = $this->createNonceStr();

		// 这里参数的顺序要按照 key 值 ASCII 码升序排序
		$string = "jsapi_ticket=".$jsapiTicket."&noncestr=".$nonceStr."&timestamp=".$timestamp."&url=".$url;

		$signature = sha1($string);
		
		$signPackage = array(
				"appId"     => $this->getM_appid(),
				"nonceStr"  => $nonceStr,
				"timestamp" => $timestamp,
				"url"       => $url,
				"signature" => $signature,
				"jsapiTicket" => $jsapiTicket,
				"rawString" => $string
		);
		return $signPackage;
	}
	
	/**
	 *ajax形式获取签名
	 */
	public function getWxJdkSignByUrl($url)
	{
		$jsapiTicket="";
		$errmsg="";
		$ret = $this->getJsApiTicket($jsapiTicket,$errmsg);
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$timestamp = time();
		$nonceStr = $this->createNonceStr();
		// 这里参数的顺序要按照 key 值 ASCII 码升序排序
		$string = "jsapi_ticket=".$jsapiTicket."&noncestr=".$nonceStr."&timestamp=".$timestamp."&url=".$url;
	
		$signature = sha1($string);
	
		$signPackage = array(
				"appId"     => $this->getM_appid(),
				"nonceStr"  => $nonceStr,
				"timestamp" => $timestamp,
				"url"       => $url,
				"signature" => $signature,
				"jsapiTicket" => $jsapiTicket,
				"rawString" => $string
		);
		return $signPackage;
	}
	
	public function getSignPackage2($appid) 
	{
		$jsapiTicket="";
		$errmsg="";
		$ret = $this->getJsApiTicket($jsapiTicket,$errmsg);
	
	
	
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	
		$timestamp = time();
		$nonceStr = $this->createNonceStr();
	
		// 这里参数的顺序要按照 key 值 ASCII 码升序排序
		$string = "jsapi_ticket=".$jsapiTicket."&noncestr=".$nonceStr."&timestamp=".$timestamp."&url=".$url;
	
		$signature = sha1($string);
	
	
	
		$signPackage = array(
				"appId"     => $appid,
				"nonceStr"  => $nonceStr,
				"timestamp" => $timestamp,
				"url"       => $url,
				"signature" => $signature,
				"jsapiTicket" => $jsapiTicket,
				"rawString" => $string
		);
		return $signPackage;
	}
	
	
	/**
	 * 生成卡券签名
	 * 
	 */
	public function getcardSignPackage($timestamp,$nonceStr,$location_id,$card_id,$card_type,$couponid,$unionid) 
	{
		$apiTicket = '';
		$errmsg = "";
		$ret = $this->getApiTicket($apiTicket,$errmsg);//apiTicket 不用文档里面的方法，直接用AppSecket即可。
		if($ret != 0)
		{
			p_file('生成卡券签名,获取$apiTicket失败：'.$errmsg);
		}
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
		
		$signdata = array();
		array_push($signdata,$apiTicket);
		
		if (!empty($card_id))
		{
			array_push($signdata,$card_id);
		}
		
		array_push($signdata,$timestamp);
		array_push($signdata,$nonceStr);
		sort( $signdata, SORT_STRING );
		p_file('$signdata=='.json_encode($signdata,JSON_UNESCAPED_UNICODE));
		$cardSign = sha1( implode( $signdata ) );

		$cardSignPackage = array(
				"code"     => '',
				"openid"     => '',
				"timestamp" => $timestamp,
				"nonce_str"  => $nonceStr,
				"signature" => $cardSign,
				"outer_id" => $couponid,
				"outer_str" => $unionid
		);
		// 注意，字段为空，但字段必须存在
		return $cardSignPackage;
	}
	
	
	/**
	 * 小程序生成卡券签名
	 *
	 */
	public function getMinCardSignPackage($card_id,$unionid)
	{
		$apiTicket='';
		$errmsg="";
		$ret = $this->getApiTicket($apiTicket,$errmsg);//apiTicket 不用文档里面的方法，直接用AppSecket即可。
	
		$nonceStr = $this->createNonceStr();
		$timestamp = time();
		
		$signdata = array();
		array_push($signdata,$apiTicket);
		
		if (!empty($card_id))
		{
			array_push($signdata,$card_id);
		}
	
		array_push($signdata,$timestamp);
		array_push($signdata,$nonceStr);
// 		array_push($signdata,$unionid);//outer_str
		
		sort( $signdata, SORT_STRING );
	
		$cardSign = sha1( implode( $signdata ) );
	
		$cardSignPackage = array(
				"code"     => '',
				"openid"     => '',
				"timestamp" => $timestamp,
				"nonce_str"  => $nonceStr,
				"signature" => $cardSign,
				"outer_str" => $unionid
		);
		// 注意，字段为空，但字段必须存在
		return $cardSignPackage;
	}

	/**
	 * 生成临时字符串
	 * @param number $length
	 * @return string
	 */
	private function createNonceStr($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}


	/**
	 * 获取网页授权读取用户openid
	 * @param String $code 网页授权后返回的code代码
	 * @param String $openid
	 * @param String $accessToken
	 * @param String $sErrmsg
	 * @return 0 成功，非0失败
	 */
	public function getAuthorizeOpenId($code,&$openid,&$accessToken,&$sErrmsg)
	{
		//返回格式{"access_token":"ACCESS_TOKEN","expires_in":7200,"refresh_token":"REFRESH_TOKEN","openid":"OPENID","scope":"SCOPE"}
		if($this->wxthirdauth=='Y' && $this->wxthirdastatus=='Y')
		{
			//说明是第三方
			$componentAccessToken='';
			$result = $this->get_component_access_token($componentAccessToken, $sErrmsg);
			if(!$result==0)
			{
				return;
			}
			//拼接获取openId的接口
			$url = "https://api.weixin.qq.com/sns/oauth2/component/access_token?appid=".$this->getM_appid()."&code=".$code."&grant_type=authorization_code&component_appid=".SysCacheMgr::getSysEnum('WX3RD_APPID')."&component_access_token=".$componentAccessToken;
		}
		else 
		{
			//拼接获取openId的接口
			$url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$this->getM_appid()."&secret=".$this->getM_appsecret()."&code=".$code."&grant_type=authorization_code";
		}

		$jsondata = HttpUtil::https_get($url);

		$json = json_decode($jsondata);

		if (!empty($json->errcode))
		{
			$sErrmsg = $json->errmsg;
			
			p_file('获取授权openid失败:');
			p_file('失败url:'.$url);
			p_file('失败明细:'.$jsondata);
			
			return $json->errcode;
		}
		else if( empty($json) ){
			$sErrmsg = '网络异常getAuthorizeOpenId';
			p_file('网络异常');
			return 1;
		}
		else
		{
			//如果有错误则重新刷新
			$accessToken = $json->access_token;
			$refreshToken = $json->refresh_token;
			$openid = $json->openid;
			return 0;
// 			if($this->wxthirdauth=='Y' && $this->wxthirdastatus=='Y')
// 			{
// 				//第三方
// 				$refreshshurl="https://api.weixin.qq.com/sns/oauth2/component/refresh_token?appid=".$this->getM_appid()."&grant_type=refresh_token&component_appid=".SysCacheMgr::getSysEnum('WX3RD_APPID')."&component_access_token=".$componentAccessToken."&refresh_token=".$refreshToken;;
// 			}
// 			else
// 			{
// 				//原始
// 				$refreshshurl="https://api.weixin.qq.com/sns/oauth2/refresh_token?appid=".$this->getM_appid()."&grant_type=refresh_token&refresh_token=".$refreshToken;
// 			}
			
// 			$refreshJsondata = HttpUtil::https_get($refreshshurl);
// 			$refreshjson = json_decode($refreshJsondata);
// 			if (!empty($refreshjson->errcode))
// 			{
// 				$sErrmsg = $refreshjson->errmsg;
// 				return $refreshjson->errcode;
// 			}
// 			else
// 			{
// 				//得到openid
// 				$openid = $refreshjson->openid;
// 				return 0;
// 			}
		}
	}
	
	/**
	 * 创建固定的二维码，产生一个ticket,用于以后换取二维码图片
	 * @param string $qrcode
	 * @param string $ticket
	 * @param string $qrurl	二维码图片地址
	 * @param string $sErrmsg
	 */
	public function createQrcodeFixTicket($qrcode,&$ticket,&$qrurl,&$sErrmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0)
		{
			return $ret;
		}	

		$url="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=".$saccessToken;
		//参数
		$data = array(
				"action_name"=>"QR_LIMIT_STR_SCENE",
				"action_info"=>array(
						"scene"=>array(
							"scene_str"=>$qrcode
					)
				)
		);
		$data = json_encode($data,JSON_UNESCAPED_UNICODE);
		//调用发送接口
		$jsondata = HttpUtil::https_post($url,$data);
		$retobj = json_decode($jsondata);
		if (!empty($retobj->errcode))
		{
			$sErrmsg = $retobj->errmsg;
			
			p_file('wxsdk中createQrcodeFixTicket失败:');
			p_file('失败data:'.$data);
			p_file('失败明细:'.$jsondata);
			
			return $retobj->errcode;
		}
		else if(empty($retobj)){
			$sErrmsg = '网络异常createQrcodeFixTicket';
			return 1;
		}		
		else
		{
			$ticket = $retobj->ticket;
			$qrurl =  $retobj->url;
		}
		
		return 0;		
	}
	
	
	/**
	 * 创建临时的二维码，产生一个ticket,用于以后换取二维码图片
	 * @param string $qrcode
	 * @param string $ticket
	 * @param string $qrurl	二维码图片地址
	 * @param string $sErrmsg
	 */
	public function createQrcodeTempStrTicket($qrcode,&$ticket,&$qrurl,&$sErrmsg,$token)
	{
		//得到accessToken
		$saccessToken=$token;
// 		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
// 		if ($ret != 0)
// 		{
// 			return $ret;
// 		}
	
		$url="https://api.weixin.qq.com/cgi-bin/qrcode/create?access_token=".$saccessToken;
		//参数 30天
		$data = array(
				"expire_seconds"=>2592000,
				"action_name"=>"QR_STR_SCENE",
				"action_info"=>array(
						"scene"=>array(
								"scene_str"=>$qrcode
						)
				)
		);
		$data = json_encode($data,JSON_UNESCAPED_UNICODE);
		//调用发送接口
		$jsondata = HttpUtil::https_post($url,$data);
		$retobj = json_decode($jsondata);
		if (!empty($retobj->errcode))
		{
			$sErrmsg = $retobj->errmsg;
			p_file('token'.$saccessToken);	
			p_file('wxsdk中createQrcodeTempStrTicket失败:');
			p_file('失败data:'.$data);
			p_file('失败明细:'.$jsondata);
				
			return $retobj->errcode;
		}
		else if(empty($retobj)){
			$sErrmsg = '网络异常createQrcodeTempStrTicket';
			return 1;
		}
		else
		{
			$ticket = $retobj->ticket;
			$qrurl =  $retobj->url;
		}
	
		return 0;
	}
	

	/**
	 * 创建问卷调查小程序的二维码
	 * @param string $qrcode
	 * @param string $ticket
	 * @param string $qrurl	二维码图片地址
	 * @param string $sErrmsg
	 */
	public function createVoteQrcodeFixTicket($qrcode,&$ticket,&$qrurl,$path,$width,$minprog,&$sErrmsg)
	{
		header('Content-type: text/html; charset=utf-8');
		$urls="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$minprog['app_id']."&secret=".$minprog['app_secret'];
		$jsondatas = HttpUtil::https_post($urls);
		$retsaccessTokenobj = json_decode($jsondatas);
		$saccessToken=$retsaccessTokenobj->access_token;
		
		//得到accessToken
		//$saccessToken="";
		//$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		//if ($ret != 0)
		//{
		//	return $ret;
		//}
		$url="https://api.weixin.qq.com/cgi-bin/wxaapp/createwxaqrcode?access_token=".$saccessToken;
		//参数
		$data = array(
				"path"=>$path,
				"width"=>$width
		);
		$data = json_encode($data,JSON_UNESCAPED_UNICODE);
		//调用发送接口
		$jsondata = HttpUtil::https_post($url,$data);
		
		return $jsondata;
	}
	
	/**
	 * 创建卡券二维码
	 * @param string $qrcode
	 * @param string $ticket
	 * @param string $qrurl	二维码图片地址
	 * @param string $sErrmsg
	 */
	public function createCardQrcodeTicket($qrcode,&$ticket,&$qrurl,&$sErrmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0)
		{
			return $ret;
		}
	
		$url="https://api.weixin.qq.com/card/qrcode/create?access_token=".$saccessToken;
		//参数
		$data = array(
			"action_name"=>"QR_CARD",
			//"expire_seconds"=> 1800,	//些参数不能传，不则会过期
			"action_info"=>array(
				"card"=>array(
					"card_id"=> $qrcode,
					"is_unique_code"=> false ,
					"outer_id" => 1
				)

			)
		);
		$data = json_encode($data,JSON_UNESCAPED_UNICODE);
		//调用发送接口
		$jsondata = HttpUtil::https_post($url,$data);
		$retobj = json_decode($jsondata);
		if (!empty($retobj->errcode))
		{
			$sErrmsg = $retobj->errmsg;
			
			p_file('wxsdk中createCardQrcodeTicket失败:');
			p_file('失败data:'.$data);
			p_file('失败明细:'.$jsondata);
			
			return $retobj->errcode;
		}
		else if(empty($retobj)){
			$sErrmsg = '网络异常createCardQrcodeTicket';
			return 1;
		}
		else
		{
			$ticket = $retobj->ticket;
			$qrurl =  $retobj->url;
		}
	
		return 0;
	}
	
	/**
	 * 获取用户有会员信息
	 * @return Ambigous <\Common\Lib\0, number>
	 */
	public function getUserInfo($openid,array &$userinfo,&$sErrmsg)
	{
		if(empty($openid) || strtolower($openid)=='null' ){
			$sErrmsg = "加载资料错误，请关闭页面重新进入";
			return 1;
		}
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0)
		{
			return $ret;
		}		
		$url="https://api.weixin.qq.com/cgi-bin/user/info?access_token=".$saccessToken."&openid=".$openid."&lang=zh_CN";
		$userJsondata = HttpUtil::https_get($url);
		$userjson = json_decode($userJsondata);
		if (!empty($userjson->errcode))
		{
			$sErrmsg = $userjson->errmsg;
			
			p_file('获取用户会员信息失败:');
			p_file('失败url:'.$url);
			p_file('失败明细:'.$userJsondata);
			p_file('令牌$saccessToken='.$saccessToken);
			p_file('微信用户$openid='.$openid);
			return $userjson->errcode;
		}
		else if(empty($userjson)){
			$sErrmsg = '网络异常getUserInfo';
			return 1;
		}
		else
		{
			$openid = $userjson->openid;
			$userinfo = array(
				"subscribe"=>$userjson->subscribe,
				"nickname"=>$userjson->nickname,
				"sex"=>$userjson->sex,
				"city"=>$userjson->city,
				"province"=>$userjson->province,
				"country"=>$userjson->country,
				"headimgurl"=>$userjson->headimgurl,
				"subscribe_time"=>$userjson->subscribe_time,
				"unionid"=>$userjson->unionid,
				"remark"=>$userjson->remark
			);
			return 0;
		}
		
	}
	
	/**
	 * 上传图片，本接口所上传的图片不占用公众号的素材库中图片数量的5000个的限制。图片仅支持jpg/png格式，大小必须在1MB以下。 (认证后的订阅号可用)
	 * 注意：上传大文件时可能需要先调用 set_time_limit(0) 避免超时
	 * 注意：数组的键值任意，但文件名前必须加@，使用单引号以避免本地路径斜杠被转义
	 * @param array $data {"media":'@Path\filename.jpg'}
	 *
	 * @return 0表示成功   非0是错语代码
	 */
	public function uploadImg($data,&$url,&$errMsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{	
			p_file('获取token报错：'.$errMsg);
			return $ret;
		}		
		//原先的上传多媒体文件接口使用 self::UPLOAD_MEDIA_URL 前缀
		$purl="https://api.weixin.qq.com/cgi-bin/media/uploadimg?access_token=".$saccessToken;
		$result = HttpUtil::http_post($purl,$data,true);
		$json = json_decode($result,true);
		//注意用[]方式读取数据，否则返回不正确
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
			
			p_file('wxsdk中uploadImg失败:');
			p_file('失败明细:'.$result);
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$sErrmsg = '网络异常uploadImg';
			p_file('网络异常');
			return 1;
		}
		else 
		{
			$url = $json['url'];
			return 0;
		}
	}	
	
	
	/**
	 * 上传获得图片的mediaid与url
	 * @param 	array $data {"media":'@Path\filename.jpg'}
	 * @param	$imagetype 媒体文件类型：分别有图片（image）、语音（voice）、视频（video）和缩略图（thumb）
	 * @param	&$url
	 * @param 	&$mediaid,
	 * @param 	&$errMsg
	 * 上传图片，本接口所上传的图片不占用公众号的素材库中图片数量的5000个的限制。图片仅支持jpg/png格式，大小必须在1MB以下。 (认证后的订阅号可用)
	 * 注意：上传大文件时可能需要先调用 set_time_limit(0) 避免超时
	 * 注意：数组的键值任意，但文件名前必须加@，使用单引号以避免本地路径斜杠被转义
	 *
	 * @return 0表示成功   非0是错语代码
	 */
	public function uploadGetMediaid($data,$imagetype,&$url,&$mediaid,&$errMsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			p_file('获取token报错：'.$errMsg);
			return $ret;
		}
		//原先的上传多媒体文件接口使用 self::UPLOAD_MEDIA_URL 前缀
		$purl="https://api.weixin.qq.com/cgi-bin/material/add_material?access_token=".$saccessToken."&type=".$imagetype;
		$result = HttpUtil::http_post($purl,$data,true);
		$json = json_decode($result,true);
		//注意用[]方式读取数据，否则返回不正确
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
				
			p_file('wxsdk中uploadGetMediaid失败:');
			p_file('失败明细:'.$result);
				
			return $json['errcode'];
		}
		else if( empty($json) ){
			$sErrmsg = '网络异常uploadGetMediaid';
			p_file('网络异常');
			return 1;
		}
		else
		{
			$url = $json['url'];
			$mediaid = $json['media_id'];
			return 0;
		}
	}	
	
	/**
	 * 创建一个微信卡券
	 * @param array $data
	 * @param string $cardid
	 * @param string $errMsg
	 * @return 0表示成功   非0是错语代码
	 */
	public function setCardField($data,&$errmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errmsg);
		if ($ret != 0)
		{
			return $ret;
		}
		//创建卡券
		$url="https://api.weixin.qq.com/card/membercard/activateuserform/set?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
				
		$json = json_decode($result,true);//得到的是数组
		
		if (!empty($json['errcode'])) {
			$errmsg = $json['errmsg'];
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errmsg = '网络异常createCard';
			p_file('网络异常:createCard');
			return 1;
		}
		else
		{
			return 0;
		}				
	}
	
	/**
	 * 创建一个微信卡券
	 * @param array $data
	 * @param string $cardid
	 * @param string $errMsg
	 * @return 0表示成功   非0是错语代码
	 */
	public function getCardWidgetLink($data,&$link,&$errmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errmsg);
		if ($ret != 0)
		{
			p_file("getCardWidgetLink  getAccessToken:".$errmsg);
			return $ret;
		}
		//创建卡券
		$url="https://api.weixin.qq.com/card/membercard/activate/geturl?access_token=".$saccessToken;

		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
				
		$json = json_decode($result,true);//得到的是数组
		
		if (!empty($json['errcode'])) {
			$errmsg = $json['errmsg'];
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errmsg = '网络异常createCard';
			p_file('网络异常:createCard');
			return 1;
		}
		else
		{
			
			$link = $json['url'];//urldecode($json['url']);
			return 0;
		}				
	}
	
	
	/**
	 * 跳转 读取用户开卡组件信息
	 * @param array $data
	 * @param string $cardid
	 * @param string $errMsg
	 * @return 0表示成功   非0是错语代码
	 */
	public function getUserCardWidgetInfo($data,&$infodata,&$errmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errmsg);
		if ($ret != 0)
		{
			return $ret;
		}
		//创建卡券
		$url="https://api.weixin.qq.com/card/membercard/activatetempinfo/get?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
				
		$json = json_decode($result,true);//得到的是数组
		
		if (!empty($json['errcode'])) {
			$errmsg = $json['errmsg'];
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errmsg = '网络异常createCard';
			p_file('网络异常:createCard');
			return 1;
		}
		else
		{
			$infodata = $json['info'];
			p_file('开卡组件信息 getUserCardWidgetInfo $infodata=='.json_encode($infodata,JSON_UNESCAPED_UNICODE));
			return 0;
		}				
	}
	
	/**
	 * 非跳转 读取用户开卡组件信息
	 * @param array $data
	 * @param string $cardid
	 * @param string $errMsg
	 * @return 0表示成功   非0是错语代码
	 */
	public function getUserCardWidgetInfoNoJump($data,&$infodata,&$errmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errmsg);
		if ($ret != 0)
		{
			return false;
		}
		//创建卡券
		$url="https://api.weixin.qq.com/card/membercard/userinfo/get?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
	
		$json = json_decode($result,true);//得到的是数组
		p_file(111111111111);
		p_file(json_encode($json));
		p_file(111111111111);
		if (!empty($json['errcode'])) {
			$errmsg = $json['errmsg'];
			p_file('getUserCardWidgetInfoNoJump');
			p_file($errmsg);
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常createCard';
			p_file('网络异常:createCard');
			return false;
		}
		else
		{
			$infodata = $json['user_info'];
			p_file('开卡组件信息 getUserCardWidgetInfoNoJump $infodata=='.json_encode($infodata,JSON_UNESCAPED_UNICODE));
			return true;
		}
	}
	
	

	/**
	 * 非跳转读取用户开卡组件信息
	 * @param array $data
	 * @param string $cardid
	 * @param string $errMsg
	 * @return 0表示成功   非0是错语代码
	 */
	public function getUserCardWidgetInfoByCode($data,&$infodata,&$errmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errmsg);
		if ($ret != 0)
		{
			return $ret;
		}
		//创建卡券
		$url="https://api.weixin.qq.com/card/code/get?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
	
		$json = json_decode($result,true);//得到的是数组
	
		if (!empty($json['errcode'])) {
			$errmsg = $json['errmsg'];
				
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errmsg = '网络异常createCard';
			p_file('网络异常:createCard');
			return 1;
		}
		else
		{
			p_file(json_encode($json));
			$infodata = $json['user_info'];
			return 0;
		}
	}
	
	/**
	 * 创建一个微信卡券
	 * @param array $data
	 * @param string $cardid
	 * @param string $errMsg
	 * @return 0表示成功   非0是错语代码
	 */
	public function createCard($data,&$cardid,&$errMsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		//创建卡券
		$url="https://api.weixin.qq.com/card/create?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
				
		$json = json_decode($result,true);//得到的是数组
		
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
			
			p_file('wxsdk中createCard失败:');
			p_file('失败明细:'.$result);
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$sErrmsg = '网络异常createCard';
			p_file('网络异常:createCard');
			return 1;
		}
		else
		{
			$cardid = $json['card_id'];
			return 0;
		}				
	}
	//获取openid的所有卡券
	public function getUserCards($openID,&$errMsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			p_file('获取openid的所有卡券失败11：'.$errMsg);
			return $ret;
		}
		
		if(empty($openID)){
			$errMsg = 'openid 不存在';
			p_file('获取openid的所有卡券失败22：'.$errMsg);
			return 1;
		}
		
		$PostData = array(
			"openid"=> $openID,
			"card_id"=>''
		);
		
		$data = json_encode($PostData,JSON_UNESCAPED_UNICODE);
		
		$url="https://api.weixin.qq.com/card/user/getcardlist?access_token=".$saccessToken;
		//$result = HttpUtil::http_post($url,$data);
		$result = HttpUtil::https_post($url,$data);
		
		$json = json_decode($result,true);
		
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
			
			p_file('wxsdk中getUserCards失败:');
			p_file('失败明细:'.$result);
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errMsg = '网络异常:getUserCards';
			p_file('网络异常:getUserCards');
			return 1;
		}
		else
		{
			return $json['card_list'];
		}	
	}
	
	//解码接口
	public function decoCODE($encryptCode,&$errMsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		
		$PostData = array(
			"encrypt_code"=> $encryptCode
		);
		
		$data = json_encode($PostData,JSON_UNESCAPED_UNICODE);
		
		$url="https://api.weixin.qq.com/card/code/decrypt?access_token=".$saccessToken;
		//$result = HttpUtil::http_post($url,$data);
		$result = HttpUtil::https_post($url,$data);
		$json = json_decode($result);
		
		if (!empty($json->errcode)) {
			p_file("卡券解码出错:".$encryptCode.":".$result);
			return -1;
		}
		else if( empty($json) ){
			$errMsg = '网络异常:decoCODE';
			p_file('网络异常:decoCODE');
			return 1;
		}
		else{
			return $json->code;
		}	
	}
	
	//查询Code接口
	public function checkCode($code,$cardid,&$errMsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		
		$PostData = array(
			"card_id"=> $cardid,
			"code"=> $code,
			"check_consume"=> true,
		);
		
		$data = json_encode($PostData,JSON_UNESCAPED_UNICODE);
		
		$url="https://api.weixin.qq.com/card/code/get?access_token=".$saccessToken;
		$result = HttpUtil::https_post($url,$data);
		$json = json_decode($result);
		
		if (!empty($json->errcode)) {
			p_file("卡券查码出错:");
			p_file("出错data:".$data);
			p_file("出错明细:".$result);
			return false;
		}
		else if( empty($json) ){
			$errMsg = '网络异常:checkCode';
			p_file('网络异常:checkCode');
			return false;
		}
		else
		{
			return $json->can_consume;
		}	
	}
	
	//查询卡券详情
	public function getCardInfo($cardid,&$errMsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		
		$PostData = array(
			"card_id"=> $cardid
		);
		
		$data = json_encode($PostData,JSON_UNESCAPED_UNICODE);
		
		$url="https://api.weixin.qq.com/card/get?access_token=".$saccessToken;
		//$result = HttpUtil::http_post($url,$data);
		$result = HttpUtil::https_post($url,$data);
		$json = json_decode($result,true);
		
		
		if (!empty($json['errcode'])) {
			p_file("wxsdk中getCardInfo出错:");
			p_file("出错data:".$data);
			p_file("出错明细:".$result);
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errMsg = '网络异常:getCardInfo';
			p_file('网络异常:getCardInfo');
			return 1;
		}
		else
		{
			return $json['card'];
		}	
	}


	//查询会员卡券code
// 	public function getUserCardCode($cardid,$openid,&$errMsg)
// 	{
// 		$saccessToken="";
// 		$ret = $this->getAccessToken($saccessToken,$errMsg);
// 		if ($ret != 0)
// 		{
// 			return $ret;
// 		}
		
// 		$PostData = array(
// 			"card_id"=> $cardid,
// 			"openid"=>$openid
// 		);
		
// 		$data = json_encode($PostData,JSON_UNESCAPED_UNICODE);
		
// 		$url="https://api.weixin.qq.com/card/user/getcardlist?access_token=".$saccessToken;
// 		//$result = HttpUtil::http_post($url,$data);
// 		$result = HttpUtil::https_post($url,$data);
// 		$json = json_decode($result,true);
		
		
// 		if (!$json || !empty($json['errcode'])) {
// 			return $json['errcode'];
// 		}
// 		else
// 		{
// 			return $json['card_list'];
// 		}	
// 	}
	
	
	//核销卡券 非自定义
	public function consumeCard($code,&$errMsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		
		$PostData = array(
			"code"=> $code
		);
		
		$data = json_encode($PostData,JSON_UNESCAPED_UNICODE);
		
		$url="https://api.weixin.qq.com/card/code/consume?access_token=".$saccessToken;
		//$result = HttpUtil::http_post($url,$data);
		$result = HttpUtil::https_post($url,$data);
		$json = json_decode($result,true);
		
		if ( !empty($json['errcode'])) {
			p_file("wxsdk中consumeCard出错:");
			p_file("出错data:".$data);
			p_file("出错明细:".$result);
			return false;
		}
		else if( empty($json) ){
			$errMsg = '网络异常consumeCard';
			p_file('网络异常:consumeCard');
			return false;
		}
		else
		{
			return true;
		}	
	}
	
	

	/* 
	*微信获取素材列表
	*/
	public function wxGetSucai($type,$offset,$count,&$sErrmsg){
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0){
			return $ret;
		}
	
		$SucaiReq = array(
			"type"=>$type,
			"offset"=>$offset,
			"count"=>$count
		);
	
		//转换为json,并且不能转为unicode
		$data = json_encode($SucaiReq,JSON_UNESCAPED_UNICODE);
		$url = "https://api.weixin.qq.com/cgi-bin/material/batchget_material?access_token=".$saccessToken;
		$jsondata = HttpUtil::https_post($url,$data);
		
		$retobj = json_decode($jsondata,true);
	
		if (!empty($retobj->errcode)){
			$sErrmsg = $retobj->errmsg;
			p_file("wxsdk中wxGetSucai出错:");
			p_file("出错data:".$data);
			p_file("出错明细:".$jsondata);
			return $retobj->errcode;
		}
		else if( empty($retobj) ){
			$sErrmsg = '网络异常wxGetSucai';
			p_file('网络异常:wxGetSucai');
			return 1;
		}
		else{
			return $retobj['item'];
		}
	}
	
	/*
	 * 获取素材总数
	 */	
	public function getMaterialCount(&$sErrmsg){
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0){
			p_file('获取$saccessToken失败：'.$sErrmsg);
			return $ret;
		}
		$url = "https://api.weixin.qq.com/cgi-bin/material/get_materialcount?access_token=".$saccessToken;
		$jsondata = HttpUtil::https_get($url);
		$retobj = json_decode($jsondata,true);
		
		if (!empty($retobj->errcode)){
			$sErrmsg = $retobj->errmsg;
			
			p_file("wxsdk中getMaterialCount出错:");
			p_file("出错明细:".$jsondata);
			
			return $retobj->errcode;
		}
		else if( empty($retobj) ){
			$sErrmsg = '网络异常getMaterialCount';
			p_file('网络异常:getMaterialCount');
			return 1;
		}
		else{
			return $retobj;
		}
	}
	
	/*
	 * 获取素材总数
	*/
	public function getMaterialById($media_id, &$sErrmsg){
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0){
			return $ret;
		}
	
		$SucaiReq = array(
			"media_id"=>$media_id
		);
	
		//转换为json,并且不能转为unicode
		$data = json_encode($SucaiReq,JSON_UNESCAPED_UNICODE);
		$url = "https://api.weixin.qq.com/cgi-bin/material/get_material?access_token=".$saccessToken;
		$jsondata = HttpUtil::https_post($url,$data);
	
		$retobj = json_decode($jsondata,true);
	
		if (!empty($retobj->errcode)){
			$sErrmsg = $retobj->errmsg;
			
			p_file("wxsdk中getMaterialById出错:");
			p_file("出错明细:".$jsondata);
			
			return $retobj->errcode;
		}
		else if( empty($retobj) ){
			$sErrmsg = '网络异常getMaterialById';
			p_file('网络异常:getMaterialById');
			return 1;
		}
		else{
			return $retobj['news_item'];
		}
	}
	
	/**
	 * 将微信素材保存到万象优图
	 */
	public function updateWxNewsImg(){
		
		$errmsg='';
		$filecount = $this->getMaterialCount($errmsg);

		//$filecount= 10;
// 		$ttl =  $filecount['news_count'];
// 		$start = ((intval($filecount['news_count'])-10)<0)? 0 : intval($filecount['news_count'])-10;
		//$pagesize = 10;
		//$filecount['news_count']
// 		for($i=0;$i<10;$i=$i+$pagesize){
			//$res = $this->wxGetSucai('news',$i,$i+$pagesize,$errmsg);
			$res = $this->wxGetSucai('news',0,10,$errmsg);
			p_file('updateWxNewsImgupdateWxNewsImgupdateWxNewsImgupdateWxNewsImg');
			p_file(json_encode($res,JSON_UNESCAPED_UNICODE));
			//list item
			foreach ($res as $k=>$v){
				
				$isexit = M('weixin_material')->field('update_time')->where(array('comp_id'=>$this->m_comp_id,'weixinid'=>$this->m_compid,'setup_id'=>$this->m_setup_id,'media_id'=>$v['media_id']))->find();

				if(empty($isexit)){
// 					$tempdir = ".".C('TMPL_PARSE_STRING.__UPLOAD__')."/wxMaterial/";
					$tempdir = getcwd().'/temp/'.$this->m_comp_id.'/'.uniqid();
					
					if (!file_exists($tempdir)){
						mkdir($tempdir,0777,true);
					}

					$fullfilename = $tempdir.'/'.$v['media_id'].'.jpg';
					
					p_file('$fullfilename');
					p_file($fullfilename);
					$res1 = ImageFuncUtil::downRemoteFile($v['content']['news_item'][0]['thumb_url'], $fullfilename, $errmsg);
					if($res1 == false)
					{
						p_file('素材图片获取失败:'.$errmsg);
						continue;
					}
					
					
					$upload = new UploadImgUtil($this->m_comp_id);
					//$upload = new UploadFileUtil($compid);
					$img_info = $upload->TransferFileOne($fullfilename,'wxMaterial',$v['media_id'],'jpg',array("jpg","png","gif","jpeg"));
					if($img_info==false){
						$errmsg = '获取素材出错';
						return false;
					}
					
					
					startTrans();
					$newdata=array(
							'comp_id'=>$this->m_comp_id,
							'weixinid'=>$this->m_compid,
							'media_id'=>$v['media_id'],
							'media_type'=>'news',
							'title'=>$v['content']['news_item'][0]['title'],
							'thumb_media_id'=>$v['content']['news_item'][0]['thumb_media_id'],
							'update_time'=>getdatetime($v['update_time']),
							'setup_id'=>$this->m_setup_id
					);
					$ret1 = M('weixin_material')->add($newdata);
					
					if($ret1==false){
						rollback();
						p_file('新增素材weixin_material:'.getDbError());
						continue;
					}
					
					$map = array(
						'comp_id'=>$this->m_comp_id,
						'data_type'=>'weixin_material',
						'data_num'=>$v['media_id'],
						'data_field'=>'front_cover',
					);
					
					$isexit2 = M('pic_data')->where($map)->find();
					if(empty($isexit2))
					{
						$newdata2=array(
								'comp_id'=>$this->m_comp_id,
								'data_type'=>'weixin_material',
								'data_num'=>$v['media_id'],
								'data_field'=>'front_cover',
								'image_url'=>$img_info['savepath'].$img_info['savename'],
								'image_name'=>$img_info['savename'],
								'createdate'=>getdatetime(time())
						);
						$ret2 = M('pic_data')->add($newdata2);
							
						if($ret2==false){
							rollback();
							p_file('新增素材pic_data:'.getDbError());
							continue;
						}
					}
					
		
					commit();
						
				}elseif($isexit['update_time']!=$v['update_time']){
					//更新
					$tempdir = ".".C('TMPL_PARSE_STRING.__UPLOAD__')."/wxMaterial/";
					if (!file_exists($tempdir)){
						mkdir($tempdir,0777,true);
					}
					$fullfilename = $tempdir.'/'.$v['media_id'].'.jpg';

					$res2 = ImageFuncUtil::downRemoteFile($v['content']['news_item'][0]['thumb_url'], $fullfilename, $errmsg);
					if($res2 == false)
					{
						p_file('素材图片获取失败:'.$errmsg);
						continue;
					}
					
					startTrans();
					$map=array(
							'comp_id'=>$this->m_comp_id,
							'weixinid'=>$this->m_compid,
							'media_id'=>$v['media_id'],
							'media_type'=>'news',
							'setup_id'=>$this->m_setup_id
					);
					
					$ret1 = M('weixin_material')->where($map)->save(array(
							'title'=>$v['content']['news_item'][0]['title'],
							'thumb_media_id'=>$v['content']['news_item'][0]['thumb_media_id'],
							'update_time'=>getdatetime($v['update_time'])
						)
					);
					
					if($ret1==false){
						rollback();
						p_file('更新素材weixin_material:'.getDbError());
						break;
					}
		
					$map2=array(
						'comp_id'=>$this->m_comp_id,
						'data_type'=>'weixin_material',
						'data_num'=>$v['media_id'],
						'data_field'=>'front_cover'
					);
					
					$ret2 = M('pic_data')->where($map2)->save(array('image_url'=>'wxMaterial/'.$v['media_id'].'.jpg'));
					if($ret2===false){
						rollback();
						p_file('更新素材pic_data:'.getDbError());
						break;
					}
					
					commit();
				}
				 
			}
		
// 		}
	}
	
	/* 
	*微信设置菜单
	*/
	public function wxSetMenu($compid,$setupid,$compdomain,&$sErrmsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0)
		{
			return $ret;
		}
		p_file($saccessToken);
		
		$menudata = array(
			"button"=>array(
			)
		);
		$MenuTable = M('wx_menu');
		

		
		$supmap['comp_id']=$compid;
		$supmap["setup_id"] = $setupid;
		$supmap['menu_lvl']=1;
		$menulist = $MenuTable->field("id,seqid,menu_name,menu_lvl,eventtype,url,media_id,setup_id")->where($supmap)->select();
		
		$miniappid = M('vip_minprog_setup')->where(array('comp_id'=>$compid))->getField('app_id');
		
		
		foreach ($menulist as $i => $v)
		{

			$submenu = $MenuTable->where(array("comp_id"=>$compid,"menu_lvl"=>(intval($v['seqid'])+1),"setup_id"=>$setupid))->order('seqid desc')->select();
			
			if 	( $submenu == null ) //无子菜单
			{
				$ret = $this->makeSubMenu($compid,$v["id"],$miniappid,$compdomain,$sErrmsg); 
				if (empty($ret))
				{
					return 1;
				}
				array_push($menudata["button"],$ret);
			}
			else  //有下级菜单
			{
				$childrenmenu= array(
					"name"=>$v["menu_name"],
					"sub_button"=>array()
				);
				
				foreach ($submenu as $k => $sub)
				{
					$ret = $this->makeSubMenu($compid,$sub["id"],$miniappid,$sErrmsg);
					if (empty($ret)){
						return 1;
					}
					array_push($childrenmenu["sub_button"],$ret);
				}
				array_push($menudata["button"],$childrenmenu);
			}			
		}
		
		
		$json = json_encode($menudata,JSON_UNESCAPED_UNICODE);
		
		
		$json = str_replace ( "\\/", "/", $json);
	
		$url = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=".$saccessToken;
		$jsondata = HttpUtil::https_post($url,$json);
		$retobj = json_decode($jsondata);
		if (!empty($retobj->errcode))
		{
			$sErrmsg = "发布菜单出错:".$retobj->errmsg;
			p_file('结果$retobj11：'.json_encode($retobj,JSON_UNESCAPED_UNICODE));
			p_file('菜单数据json='.$json);
			return $retobj->errcode;
		}
		else if( empty($retobj) ){
			$sErrmsg = '网络异常wxSetMenu';
			p_file('网络异常:wxSetMenu');
			return 1;
		}
		else 
		{
			return 0;
		}
	}
	
	/**
	 * 根据seqid创建子菜单数据格式
	 * @param unknown $menuseqid
	 * @param unknown $sErrmsg
	 */
	private function makeSubMenu($compid,$id,$miniappid,$compdomain,&$sErrmsg)
	{
		//第1排菜单
		$menu = array();
		$MenuTable = M('wx_menu');
		$menuname = $MenuTable->field("menu_name,eventtype,url,media_id,mini_path")->where(array("comp_id"=>$compid,"id"=>$id))->find();
		if (empty($menuname["eventtype"]))
		{
			$sErrmsg = "菜单类型不能为空";
			return 0;
		}
		if (strtolower($menuname["eventtype"]) == "view")
		{
			$menu = array(
				"type"=>"view",
				"name"=>$menuname["menu_name"],
				"url"=>$menuname["url"]
			);
		}
		else if (strtolower($menuname["eventtype"]) == "new")
		{
			$menu = array(
					"type"=>"media_id",
					"name"=>$menuname["menu_name"],
					"media_id"=>$menuname["media_id"]
			);
		}
		else if (strtolower($menuname["eventtype"]) == "miniprogram")
		{
			$menu = array(
					"type"=>"miniprogram",
					"appid"=>$miniappid,
					"name"=>$menuname["menu_name"],
					"pagepath"=>$menuname["mini_path"],
					"url"=>$menuname["url"]
			);
		}
		else
		{
			$sErrmsg = "菜单类型".$menuname["eventtype"]."未实现";
			return 0;
		}
		return $menu;
	}
	
	/**
	 * 根据seqid创建子菜单数据格式
	 * @param unknown $menuseqid
	 * @param unknown $sErrmsg
	 */
	private function makeSubMenubk($compid,$menuseqid,&$sErrmsg)
	{
		//第1排菜单
		$menu = array();
		$MenuTable = M('wx_menu');
		$menuname = $MenuTable->field("menu_name,eventtype,url,media_id")->where(array("comp_id"=>$compid,"seqid"=>$menuseqid))->find();
		if (empty($menuname["eventtype"]))
		{
			$sErrmsg = "菜单类型不能为空";
			return 0;
		}
		if (strtolower($menuname["eventtype"]) == "view")
		{
			$menu = array(
					"type"=>"view",
					"name"=>$menuname["menu_name"],
					"url"=>$menuname["url"]
			);
		}
		else if (strtolower($menuname["eventtype"]) == "news")
		{
			$menu = array(
					"type"=>"media_id",
					"name"=>$menuname["menu_name"],
					"media_id"=>$menuname["media_id"]
			);
		}
		else
		{
			$sErrmsg = "菜单类型".$menuname["eventtype"]."未实现";
			return 0;
		}
		return $menu;
	}
	
	/**
	 * 读取指定类型的缓存数据
	 * @param  string $cachedatatype	缓存数据类型
	 * 							mp_accesstoken		微信公众号缓存
	 * 							mp_jsapiticket			jsapi临时票据缓存
	 * 							mp_apiticket			api临时票据缓存
	 * 							compoment_accesstoken	公众号第三方授权缓存
	 */
	private function getCacheData($cachedatatype)
	{
		$catch_name = strtoupper($cachedatatype)."_".strtoupper($this->m_compid);
		return S($catch_name);
	}
	
	/**
	 * 设置缓存数据
	 * @param string $cachedatatype 缓存数据类型
	 * 							mp_accesstoken		微信公众号缓存
	 * 							mp_jsapiticket			jsapi临时票据缓存
	 * 							mp_apiticket			api临时票据缓存 
	 * 							compoment_accesstoken	公众号第三方授权缓存
	 * @param array $cachedata
	 * @param int $expire
	 * @return true / false
	 */
	private function setCacheData($cachedatatype,$cachedata,$expire)
	{
		$catch_name = strtoupper($cachedatatype)."_".strtoupper($this->m_compid);
		$result = S($catch_name,$cachedata,$expire);
		if (!$result)
		{
			p_file("缓存".$catch_name."的值".$cachedata."失败");
		}
		if (strtoupper($cachedatatype) == strtoupper("mp_accesstoken") || strtoupper($cachedatatype) == strtoupper("compoment_accesstoken"))	//如果accesstoken失效，则将jsapiticket，apiticket一起失效
		{
			p_file('setCachedata:'.$catch_name);
			$jsapiticket = strtoupper("mp_jsapiticket")."_".strtoupper($this->m_compid);
			S($jsapiticket,null);
			$apiticket = strtoupper("mp_apiticket")."_".strtoupper($this->m_compid);
			S($apiticket,null);			
		}
		return $result;
	}
	
	
	/**
	 * 清除缓存数据
	 * @param string $cachedatatype 缓存数据类型
	 * 							mp_accesstoken		微信公众号缓存
	 * 							mp_jsapiticket			jsapi临时票据缓存
	 * 							mp_apiticket			api临时票据缓存
	 * 							compoment_accesstoken	公众号第三方授权缓存
	 */
	public function resetCacheData($cachedatatype)
	{
		$catch_name = strtoupper($cachedatatype)."_".strtoupper($this->m_compid);
		S($catch_name,null);
		if (strtoupper($cachedatatype) == strtoupper("mp_accesstoken") || strtoupper($cachedatatype) == strtoupper("compoment_accesstoken"))	//如果accesstoken失效，则将jsapiticket，apiticket一起失效
		{
			$jsapiticket = strtoupper("mp_jsapiticket")."_".strtoupper($this->m_compid);
			S($jsapiticket,null);
			$apiticket = strtoupper("mp_apiticket")."_".strtoupper($this->m_compid);
			S($apiticket,null);
		}
	}
		
	/**
	 * 统一获取临时票据
	 * @param string $tickettype
	 * @param string $ticket
	 * @param string $sErrmsg
	 * @return Ambigous <\Common\Lib\WeiXin\0, number>|number
	 */
	private function getTicket($tickettype,&$ticket,&$sErrmsg)
	{
		//得到accessToken
		$saccessToken="";
		
		if($this->wxthirdauth=='Y' && $this->wxthirdastatus=='Y'){
			$saccessToken = M('authtoken')->where(array('auth_app_id'=>$this->getM_appid(),'tokentype'=>'WEX'))->getField('app_auth_token');
		}else{
			$ret = $this->getAccessToken($saccessToken,$sErrmsg);
			if ($ret != 0)
			{
				return $ret;
			}
		}
// 		p_file('$saccessToken'.$saccessToken);
 		if (strtoupper($tickettype)== strtoupper("Mp_JsApiTicket")){
			$ticket_sql = 'jsapiticket';
			//$ticket =$jsApiTicket;
		}else{
			$ticket_sql = 'cardapiticket';
			//$ticket =$apiTicket;
		}
		$token = M('weixin_token')->field('tokenvalue,errmsg')->where(array('appid'=>$this->getM_appid(),'tokentype'=>$ticket_sql))->find();
		if(empty($token)){
			$sErrmsg = '读取ticket不存在';
			return 1;
		}else{
			$ticket = $token['tokenvalue'];
		}
		return 0; 
		
		
	}
	
	/**
	 * 发送模板消息
	 * @param array $message		消息内容
	 * @param int  $iMsgid			返回的消息号
	 * @param string $sErrmsg		返回的错误文本
	 * @return 返回errcode 0表示成功，非0表示失败
	 */
	private function sendTemplateMsg(array $message,&$iMsgid,&$sErrmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0)
		{
			return $ret;
		}
				
		//转换为json,并且不能转为unicode
		$data = json_encode($message,JSON_UNESCAPED_UNICODE);
		
		//调用发送接口
		$jsondata = HttpUtil::https_post("https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=".$saccessToken,$data);
		$retobj = json_decode($jsondata,true);
		if ($retobj["errcode"] != "0")
		{
			$sErrmsg = $retobj["errmsg"];
			p_file("wxsdk中sendTemplateMsg出错:");
			p_file("出错明细:".$jsondata);
			return $retobj["errcode"];
		}
		if( empty($retobj) ){
			$sErrmsg = '网络异常sendTemplateMsg';
			p_file('网络异常:sendTemplateMsg');
			return 1;
		}
		$iMsgid = $retobj["msgid"];
		return 0;		
	}
	
	/**
	 * 发送模板消息
	 * @param string $templateid	模板ID
	 * @param string $touserid		用户openid
	 * @param int  $iMsgid			返回的消息号
	 * @param string $sErrmsg		返回的错误文本 
	 * @param array  $keymap		关键值名称映射  array("first"=>"first","keynote1"=>"keynote1","keynote2"=>"keynote2",	"keynote3"=>"keynote3","keynote4"=>"keynote4","keynote5"=>"keynote5","remark"=>"remark")
	 * @param string $firstdata		标题
	 * @param string $remarkdata	备注
	 * @param string $keynote1	关键值1
	 * @param string $keynote2	关键值2
	 * @param string $keynote3	关键值3
	 * @param string $keynote4	关键值4
	 * @param string $keynote5	关键值5
	 * @return 返回errcode 0表示成功，非0表示失败
	 */
	public function sendTemplateMessage($templateid,$touserid,&$iMsgid,&$sErrmsg,$keymap,$firstdata,$remarkdata,$keynote1="",$keynote2="",$keynote3="",$keynote4="",$keynote5="",$url='',$mini_pagepath='',$mini_appid)
	{
		//组合数据
		$msgdata = array(
				"touser"=>$touserid,
				"template_id"=>$templateid,
				"url"=>"",
				"data"=>array()
		);
		if (!empty($firstdata))
		{
			$keyname = $keymap["first"];
			if (empty($keyname))
			{
				$keyname="first";
			}
			$msgdata["data"][$keyname]= array("value"=>$firstdata,"color"=>"#173177");
		}
		if (!empty($keynote1))
		{
			$keyname = $keymap["keynote1"];
			if (empty($keyname))
			{
				$keyname="keynote1";
			}			
			$msgdata["data"][$keyname]= array("value"=>$keynote1,"color"=>"#173177");
		}
		if (!empty($keynote2))
		{
			$keyname = $keymap["keynote2"];
			if (empty($keyname))
			{
				$keyname="keynote2";
			}
			$msgdata["data"][$keyname]= array("value"=>$keynote2,"color"=>"#173177");
		}
		if (!empty($keynote3))
		{
			$keyname = $keymap["keynote3"];
			if (empty($keyname))
			{
				$keyname="keynote3";
			}
			$msgdata["data"][$keyname]= array("value"=>$keynote3,"color"=>"#173177");
		}	
		if (!empty($keynote4))
		{
			$keyname = $keymap["keynote4"];
			if (empty($keyname))
			{
				$keyname="keynote4";
			}
			$msgdata["data"][$keyname]= array("value"=>$keynote4,"color"=>"#173177");
		}
		if (!empty($keynote5))
		{
			$keyname = $keymap["keynote5"];
			if (empty($keyname))
			{
				$keyname="keynote5";
			}
			$msgdata["data"][$keyname]= array("value"=>$keynote5,"color"=>"#173177");
		}	
		if (!empty($remarkdata))
		{
			$keyname = $keymap["remark"];
			if (empty($keyname))
			{
				$keyname="remark";
			}
			$msgdata["data"][$keyname]= array("value"=>$remarkdata,"color"=>"#173177");
		}
		if (!empty($url))
		{
			$msgdata['url']= $url;
		}
		if (!empty($mini_pagepath) && !empty($mini_appid))
		{
			$msgdata['miniprogram']= array(
// 					"pagepath"=>$mini_pagepath,
					"path"=>$mini_pagepath,
					"appid"=>$mini_appid
			);
		}
		p_file('发送模版消息'.json_encode($msgdata,JSON_UNESCAPED_UNICODE));
		return $this->sendTemplateMsg($msgdata, $iMsgid, $sErrmsg);
	}	
	
	/*
	 *验证URL
	*@param sMsgSignature: 签名串，对应URL参数的msg_signature
	*@param sTimeStamp: 时间戳，对应URL参数的timestamp
	*@param sNonce: 随机串，对应URL参数的nonce
	*@return：true false
	*/
	public function verifyURL($sMsgSignature, $sTimeStamp, $sNonce)
	{
	
		$tmpArr = array($this->m_sToken, $sTimeStamp, $sNonce);
		sort($tmpArr, SORT_STRING);
		$tmpStr = implode( $tmpArr );
		$tmpStr = sha1( $tmpStr );
		p_file('dec sss:'.$this->m_sToken);
		p_file('dec sss:'.$tmpStr);
		if( $tmpStr == $sMsgSignature ){
			return true;
		}else{
			return false;
		}
	}	
	
	/**
	 * 将公众平台回复用户的消息加密打包.
	 * <ol>
	 *    <li>对要发送的消息进行AES-CBC加密</li>
	 *    <li>生成安全签名</li>
	 *    <li>将消息密文和安全签名打包成xml格式</li>
	 * </ol>
	 *
	 * @param $replyMsg string 公众平台待回复用户的消息，xml格式的字符串
	 * @param $timeStamp string 时间戳，可以自己生成，也可以用URL参数的timestamp
	 * @param $nonce string 随机串，可以自己生成，也可以用URL参数的nonce
	 * @param &$encryptMsg string 加密后的可以直接回复用户的密文，包括msg_signature, timestamp, nonce, encrypt的xml格式的字符串,
	 *                      当return返回0时有效
	 *
	 * @return int 成功0，失败返回对应的错误码
	 */
	public function encryptMsg($sReplyMsg, $sTimeStamp, $sNonce, &$sEncryptMsg)
	{
		$pc = new Prpcrypt($this->m_sEncodingAesKey);
	
		//加密
		$array = $pc->encrypt($sReplyMsg, $this->m_sCorpid);
		$ret = $array[0];
		if ($ret != 0) {
			return $ret;
		}
	
		if ($sTimeStamp == null) {
			$sTimeStamp = time();
		}
		$encrypt = $array[1];
	
		//生成安全签名
		$sha1 = new SHA1();
		$array = $sha1->getSHA1($this->m_sToken, $sTimeStamp, $sNonce, $encrypt);
		$ret = $array[0];
		if ($ret != 0) {
			return $ret;
		}
		$signature = $array[1];
	
		//生成发送的xml
		$xmlparse = new XMLParse();
		$sEncryptMsg = $xmlparse->generate($encrypt, $signature, $sTimeStamp, $sNonce);
		return ErrorCode::$OK;
	}
	
	/**
	 * 检验消息的真实性，并且获取解密后的明文.
	 * <ol>
	 *    <li>利用收到的密文生成安全签名，进行签名验证</li>
	 *    <li>若验证通过，则提取xml中的加密消息</li>
	 *    <li>对消息进行解密</li>
	 * </ol>
	 *
	 * @param $msgSignature string 签名串，对应URL参数的msg_signature
	 * @param $timestamp string 时间戳 对应URL参数的timestamp
	 * @param $nonce string 随机串，对应URL参数的nonce
	 * @param $postData string 密文，对应POST请求的数据
	 * @param &$msg string 解密后的原文，当return返回0时有效
	 *
	 * @return int 成功0，失败返回对应的错误码
	 */
	public function decryptMsg($sMsgSignature, $sTimeStamp = null, $sNonce, $sPostData, &$sMsg)
	{
		if (strlen($this->m_sEncodingAesKey) != 43) {
			return ErrorCode::$IllegalAesKey;
		}
	
		$pc = new Prpcrypt($this->m_sEncodingAesKey);
	
		//提取密文
		$xmlparse = new XMLParse;
		$array = $xmlparse->extract($sPostData);
		$ret = $array[0];
	
		if ($ret != 0) {
			return $ret;
		}
	
		if ($sTimeStamp == null) {
			$sTimeStamp = time();
		}
	
		$encrypt = $array[1];
		$touser_name = $array[2];
	
		//验证安全签名
		$sha1 = new SHA1;
		$array = $sha1->getSHA1($this->m_sToken, $sTimeStamp, $sNonce, $encrypt);
		$ret = $array[0];
	
		if ($ret != 0) {
			return $ret;
		}
	
		$signature = $array[1];
		if ($signature != $sMsgSignature) {
			return ErrorCode::$ValidateSignatureError;
		}
	
		$result = $pc->decrypt($encrypt, $this->m_sCorpid);
		if ($result[0] != 0) {
			return $result[0];
		}
		$sMsg = $result[1];
	
		return ErrorCode::$OK;
	}
	
	/**
	 * 下载 指定编号的消息模板
	 * @param string $temp_num
	 * @param string &$templ_id
	 * @param string &$sErrMsg
	 * @return 0成功/非0 失败
	 */
	public function downloadTemplate($temp_num,&$templ_id,&$sErrMsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		$message = array(
			"template_id_short"=>$temp_num
		);
		
		$data = json_encode($message,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post("https://api.weixin.qq.com/cgi-bin/template/api_add_template?access_token=".$saccessToken,$data);
		
		$json = json_decode($jsondata);
		if (!empty($json->errcode) || empty($json))
		{
			$sErrMsg = $json->errmsg;
			p_file("wxsdk中downloadTemplate出错:");
			p_file("出错明细:".$jsondata);
			return $json->errcode;
		}	
		if( empty($json) ){
			$sErrmsg = '网络异常downloadTemplate';
			p_file('网络异常:downloadTemplate');
			return 1;
		}	
		$templ_id = $json->template_id;
		return 0;		
	}

	/**
	 * 信息发布启用模板消息
	 * @param string $temp_num
	 * @param string &$templ_id
	 * @param string &$sErrMsg
	 * @return 0成功/非0 失败
	 */
	public function addMiniMsgTemplate($msg_id,$fieldslist,&$templ_id,&$sErrMsg)
	{

		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		$message = array(
			"id"=>'AT0634',
			"keyword_id_list"=>[14,2,8,1]
		);
		
		$data = json_encode($message,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post("https://api.weixin.qq.com/cgi-bin/wxopen/template/add?access_token=".$saccessToken,$data);
		echo $jsondata;die;
		$json = json_decode($jsondata);
		
		if (!empty($json->errcode) || empty($json))
		{
			$sErrMsg = $json->errmsg;
			p_file("wxsdk中downloadTemplate出错:");
			p_file("出错明细:".$jsondata);
			return $json->errcode;
		}
		if( empty($json) ){
			$sErrmsg = '网络异常downloadTemplate';
			p_file('网络异常:downloadTemplate');
			return 1;
		}
		$templ_id = $json->template_id;
		return 0;
	}
	
	/**
	 * 接口激活会员卡
	 * @param string $temp_num
	 * @param string &$templ_id
	 * @param string &$sErrMsg
	 * @return 0成功/非0 失败
	 */
	public function apiactivecard($data,&$errMsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		$url="https://api.weixin.qq.com/card/membercard/activate?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
				
		$json = json_decode($result,true);//得到的是数组
		
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
			
			p_file('wxsdk激活会员卡:');
			p_file('出错数据:'.$jsondata);
			p_file('出错明细:'.$result);
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errMsg = '网络异常:apiactivecard';
			p_file('网络异常:apiactivecard');
			return 1;
		}
		else
		{
			return 0;
		}				
	}
	
	/**
	 * 查看某个会员的会员卡状态
	 * @param string $temp_num
	 * @param string &$templ_id
	 * @param string &$sErrMsg
	 * @return 0成功/非0 失败
	 */
	public function apigetvipCard($data,&$errMsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		$url="https://api.weixin.qq.com/card/membercard/userinfo/get?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
	
		$json = json_decode($result,true);//得到的是数组
		
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
			
			p_file('wxsdk拉取会员卡状态:');
			p_file('出错数据:'.$jsondata);
			p_file('出错明细:'.$result);
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errMsg = '网络异常:apigetvipCard';
			p_file('网络异常:apigetvipCard');
			return 1;
		}
		else{
			return $json['has_active'];
		}
	}
	
	/**
	 * 更新会员卡字段
	 * @param string $temp_num
	 * @param string &$templ_id
	 * @param string &$sErrMsg
	 * @return 0成功/非0 失败
	 */
	public function apiupdatecard($data,&$errMsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		$url="https://api.weixin.qq.com/card/update?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		p_file('apiupdatecard   $data=='.json_encode($data));
		p_file('apiupdatecard   $jsondata=='.json_encode($jsondata));
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
	
		$json = json_decode($result,true);//得到的是数组
		
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
			p_file("wxsdk中apiupdatecard出错:");
			p_file('出错数据:'.$jsondata);
			p_file("出错明细:".$result);
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errMsg = '网络异常:apiupdatecard';
			p_file('网络异常:apiupdatecard');
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	public function apidisablecard($data,&$errMsg){
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		$url="https://api.weixin.qq.com/card/delete?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
		
		$json = json_decode($result,true);//得到的是数组
		
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
			p_file("wxsdk中apidisablecard出错:");
			p_file('出错数据:'.$jsondata);
			p_file("出错明细:".$result);
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errMsg = '网络异常:apidisablecard';
			p_file('网络异常:apidisablecard');
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	/**
	 * 更新卡中会员的信息
	 * @param string $temp_num
	 * @param string &$templ_id
	 * @param string &$sErrMsg
	 * @return 0成功/非0 失败
	 */
	public function apiupdatecardvipinfo($data,&$errMsg)
	{
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		$url="https://api.weixin.qq.com/card/membercard/updateuser?access_token=".$saccessToken;
		$jsondata = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = str_replace ( "\\/", "/", $jsondata);
		$result = HttpUtil::https_post($url,$jsondata);
	
		$json = json_decode($result,true);//得到的是数组
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
			
			p_file("wxsdk中apiupdatecardvipinfo出错:");
			p_file('出错数据:'.$jsondata);
			p_file("出错明细:".$result);
			
			return $json['errcode'];
		}
		else if( empty($json) ){
			$errMsg = '网络异常:apiupdatecardvipinfo';
			p_file('网络异常:apiupdatecardvipinfo');
			return 1;
		}
		else
		{
			return 0;
		}
	}
	
	
	
	
	/////////////////////////////开放平台////////////////////////////////////////
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * 获取第三方组件方component_access_token接口,并根据失效时间暂存起来
	 * intval(a,b);b:为进制数
	 * @return 0 成功，非0失败
	 */
	public function get_component_access_token(&$componentAccessToken,&$sErrmsg)
	{
// 		$catchname = "component_access_token";
		$token = M("weixin_token")->field('tokenvalue,expiredate,lastdate,errmsg')->where(array('appid'=>SysCacheMgr::getSysEnum('WX3RD_APPID'),'tokentype'=>'accesstoken'))->find();
		if(empty($token)){
			$sErrmsg = '读取token失败';
			return 1;
		}else{
			$componentAccessToken = $token['tokenvalue'];
			return  0;
		}

	}
	
	
	
	/**
	 * 获取pre_auth_code接口,
	 */
	public function get_pre_auth_code(&$preAuthCode,&$sErrmsg){
		$catchname = "pre_auth_code";
		if (!($accessToken = $this->getCacheData($catchname))){
			$componentAccessToken='';
			$result = $this->get_component_access_token($componentAccessToken, $sErrmsg);
			if(!$result==0){
				return false;
			}
			$url="https://api.weixin.qq.com/cgi-bin/component/api_create_preauthcode?component_access_token=".$componentAccessToken;
			$data = array(
				"component_appid"=>SysCacheMgr::getSysEnum('WX3RD_APPID'),
			);
			$data = json_encode($data,JSON_UNESCAPED_UNICODE);
			//调用发送接口
			$jsondata = HttpUtil::https_post($url,$data);
			$json = json_decode($jsondata);
			if (!empty($json->errcode) || empty($json)){
				$sErrmsg = $json->errmsg;
				return false;
				//return $json->errcode;
			}
			else if( empty($json) ){
				$sErrmsg = '网络异常get_pre_auth_code';
				p_file('网络异常:get_pre_auth_code');
				return false;
			}
			else{
				$preAuthCode = $json->pre_auth_code;
				$expires_in = intval($json->expires_in,10) - 600;	//减去比返回预定值提前失效的时间  在20分钟过期
				$this->setCacheData($catchname, $accessToken, $expires_in);
				return true;
			}
		}else{
			return true;
		}
	}
	
	public function get_authorizer_access_token($auth_code,&$sErrmsg)
	{
		$componentAccessToken='';
		$result = $this->get_component_access_token($componentAccessToken, $sErrmsg);
		if(!$result==0)
		{
			//获取component_access_token出错
		}

		$url="https://api.weixin.qq.com/cgi-bin/component/api_query_auth?component_access_token=".$componentAccessToken;
		$data = array(
			"component_appid"=>SysCacheMgr::getSysEnum('WX3RD_APPID'),
			"authorization_code"=> $auth_code,
		);
		$data = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post($url,$data);
		$json = json_decode($jsondata);
		$json2 = json_decode($jsondata->authorization_info);
		
		if (!empty($json->errcode) )
		{
			$sErrmsg = $json->errmsg;
			return $json->errcode;
		}
		else if( empty($json) ){
			$sErrmsg = '网络异常get_authorizer_access_token';
			p_file('网络异常:get_authorizer_access_token');
			return false;
		}
		else
		{
			$authinfo = $json->authorization_info;
			$authorizer_appid = $authinfo->authorizer_appid;
			$authorizer_access_token = $authinfo->authorizer_access_token;
			$authorizer_refresh_token= $authinfo->authorizer_refresh_token;
			
			return $authinfo;
		}
	}
	
	//获取授权方的信息
	public function get_authorizer_info($compid,$tokentype,&$sErrmsg)
	{
		$componentAccessToken='';
		$result = $this->get_component_access_token($componentAccessToken, $sErrmsg);
		
		if(!$result==0)
		{
			return false;
		}
		
		$url="https://api.weixin.qq.com/cgi-bin/component/api_get_authorizer_info?component_access_token=".$componentAccessToken;
		
		if($tokentype=='WEX'){
			$authInfo = M('authtoken')->field('auth_app_id,app_refresh_token')->where(array('comp_id'=>$compid,'tokentype'=>'WEX'))->find();
		}else{
			$authInfo = M('authtoken')->field('auth_app_id,app_refresh_token')->where(array('comp_id'=>$compid,'tokentype'=>'MIN'))->find();
		}
		
		$data = array(
			"component_appid"=>SysCacheMgr::getSysEnum('WX3RD_APPID'),
			"authorizer_appid"=> $authInfo['auth_app_id'],
		);
		$data = json_encode($data,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post($url,$data);
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$sErrmsg = $json->errmsg;
			return $json->errcode;
		}
		else if( empty($json) ){
			$sErrmsg = '网络异常get_authorizer_info';
			p_file('网络异常:get_authorizer_info');
			return 1;
		}
		else
		{
			$respone = $json->authorizer_info;
			return $respone;
			
		}
	}
	
	
	//从数据库读取授权的数据
	public function getAutherTokenFromDb($auther_appid,&$errmsg){
		p_file('getAutherTokenFromDb auther_appid'.$auther_appid);
		$authInfo = M('authtoken')->field('app_auth_token,auth_app_id,app_refresh_token,expires_date')->where(array('auth_app_id'=>$auther_appid))->find();
		if(empty($authInfo)){
			$errmsg = '授权数据不存在';
			return false;
		}

		return $authInfo;
	}
	
	//设置服务器域名
	public function setMiniDomainforVendor($compid,$auther_appid,$domain_config,&$errmsg){
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			return false;
		}
		
		$url="https://api.weixin.qq.com/wxa/modify_domain?access_token=".$authInfo['app_auth_token'];
		
		$data = json_encode($domain_config,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post($url,$data);
		
		p_file('setMiniDomainforVendor'.$jsondata);
		
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$errmsg = $json->errmsg;
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常setMiniDomainforVendor';
			return false;
		}
		else
		{
			return $json;
		}
	}
	
	//给商家上传小程序
	public function uploadPackageforVendor($compid,$auther_appid,$package_config,&$errmsg)
	{
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			return false;
		}
	
		$url="https://api.weixin.qq.com/wxa/commit?access_token=".$authInfo['app_auth_token'];
		
		$data = json_encode($package_config,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post($url,$data);
		
		p_file('uploadPackageToVendor'.$jsondata);
		
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$errmsg = $json->errmsg;
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常uploadPackageToVendor';
			return false;
		}
		else
		{
			return $json;
		}
	}
	
	
	//给商家上传小程序
	public function getVendorCate($compid,$auther_appid,&$errmsg)
	{
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			return false;
		}
	
		$url="https://api.weixin.qq.com/wxa/get_category?access_token=".$authInfo['app_auth_token'];
	
		$jsondata = HttpUtil::https_get($url);
	
		p_file('getVendorCate'.$jsondata);
	
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$errmsg = $json->errmsg;
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常getVendorCate';
			return false;
		}
		else
		{
			return $json;
		}
	}
	
	//提交审核
	public function aduitPackageforVendor($compid,$auther_appid,$package_config,&$errmsg){
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			return false;
		}
		
		$url="https://api.weixin.qq.com/wxa/submit_audit?access_token=".$authInfo['app_auth_token'];
		
		$data = json_encode($package_config,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post($url,$data);
		
		p_file('aduitPackageforVendor'.$jsondata);
		
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$errmsg = $json->errmsg;
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常aduitPackageforVendor';
			return false;
		}
		else
		{
			return $json;
		}
	}

	//提交审核
	public function queryAduitStatus($compid,$auther_appid,$package_config,&$errmsg){
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			return false;
		}
		
		$url="https://api.weixin.qq.com/wxa/get_auditstatus?access_token=".$authInfo['app_auth_token'];
		
		$data = json_encode($package_config,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post($url,$data);
		
		p_file('queryAduitStatus'.$jsondata);
		
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$errmsg = $json->errmsg;
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常queryAduitStatus';
			return false;
		}
		else
		{
			return $json;
		}
	}
	
	//提交发布
	public function releasePackageforVendor($compid,$auther_appid,&$errmsg){
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			return false;
		}
		$package_config = new \stdClass();
		
		$url="https://api.weixin.qq.com/wxa/release?access_token=".$authInfo['app_auth_token'];
	
		$data = json_encode($package_config,JSON_UNESCAPED_UNICODE);
		p_file('$data'.$data);
		$jsondata = HttpUtil::https_post($url,$data);
	
		p_file('releasePackageforVendor'.$jsondata);
	
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$errmsg = $json->errmsg;
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常releasePackageforVendor';
			return false;
		}
		else
		{
			return $json;
		}
	}
	//给商家上传小程序
	public function getMinaPreviewImg($compid,$auther_appid,&$errmsg)
	{
		
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			p_file($errmsg);
			return false;
		}
	
		$url="https://api.weixin.qq.com/wxa/get_qrcode?access_token=".$authInfo['app_auth_token'];
// 		header($url);
		$jsondata = HttpUtil::https_get($url);
		
		header('Content-type: image/jpg');
// 		file_get_contents
		echo $jsondata;
// 		echo '<img src="'.$jsondata.'" /> />';
// 		$json = json_decode($jsondata);
// 		if (!empty($json->errcode) )
// 		{
// 			$sErrmsg = $json->errmsg;
// 			return false;
// 		}
// 		else if( empty($json) ){
// 			$sErrmsg = '网络异常uploadPackageToVendor';
// 			return false;
// 		}
// 		else
// 		{
// 			echo $jsondata;
// 		}
	}
	
	
	
	//添加开放账号
	public function addOpenAccount($compid,$auther_appid,&$errmsg)
	{
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			return false;
		}
		$package_config = array(
			'appid'=>$auther_appid
		);
		
		$url="https://api.weixin.qq.com/cgi-bin/open/create?access_token=".$authInfo['app_auth_token'];
		
		$data = json_encode($package_config,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post($url,$data);
		p_file('addOpenAccount'.$jsondata);
		
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$errmsg = $json->errmsg;
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常addOpenAccount';
			return false;
		}
		else
		{
			return $json;
		}
	
	}
	
	//绑定到开放账号
	public function bindOpenAccount($compid,$auther_appid,$open_appid,&$errmsg)
	{
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			return false;
		}
		$package_config = array(
			'appid'=>$auther_appid,
			'open_appid'=>$open_appid
		);
	
		$url="https://api.weixin.qq.com/cgi-bin/open/bind?access_token=".$authInfo['app_auth_token'];
	
		$data = json_encode($package_config,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post($url,$data);
		p_file('bindOpenAccount'.$jsondata);
	
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$errmsg = $json->errmsg;
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常bindOpenAccount';
			return false;
		}
		else
		{
			return $json;
		}
	
	}

	//查询开放账号
	public function queryBindOpenAccount($compid,$auther_appid,&$errmsg)
	{
		$authInfo = $this->getAutherTokenFromDb($auther_appid, $errmsg);
		if($authInfo==false){
			return false;
		}
		$package_config = array(
			'appid'=>$auther_appid
		);
		
		$url="https://api.weixin.qq.com/cgi-bin/open/get?access_token=".$authInfo['app_auth_token'];
		
		$data = json_encode($package_config,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post($url,$data);
		p_file('queryBindOpenAccount'.$jsondata);
		
		$json = json_decode($jsondata);
		if (!empty($json->errcode) )
		{
			$errmsg = $json->errmsg;
			return false;
		}
		else if( empty($json) ){
			$errmsg = '网络异常queryBindOpenAccount';
			return false;
		}
		else
		{
			return $json;
		}
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	////////////////// 客服///////////////////////
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/**
	 * 发送客户服务回复消息
	 * @param unknown $touser
	 * @param unknown $msgtype
	 * @param unknown $msgcontent
	 * @param unknown $sErrmsg
	 * @return Ambigous <\Common\Lib\WeiXin\0, number>|mixed|number
	 */
	public function sendCustomerServiceMsg($touser,$msgtype,$msgcontent,&$sErrmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrmsg);
		if ($ret != 0)
		{	
			p_file('getAccessToken客服回复错误:'.$sErrmsg);
			return $ret;
		}
		
		if (strtolower($msgtype)=="text")
		{
			$content = array("content"=>$msgcontent);
		}
		else if (strtolower($msgtype)=="image")
		{
			$content = array("media_id"=>$msgcontent);
		}
		else if (strtolower($msgtype)=="file")
		{
			$content = array("media_id"=>$msgcontent);
		}
		$data= array(
			"touser"=>$touser,
			"msgtype"=>$msgtype,
			$msgtype=>$content
		);
		//转换为json,并且不能转为unicode
		$data = json_encode($data,JSON_UNESCAPED_UNICODE);
		//调用发送接口
		$jsondata = HttpUtil::https_post("https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=".$saccessToken,$data);
		$retobj = json_decode($jsondata,true);
		if ($retobj["errcode"] != "0")
		{
			$sErrmsg = $retobj["errmsg"];
			p_file('$retobj='.json_encode($retobj));
			p_file('调用接口，客服回复错误:'.$sErrmsg);
			return $retobj["errcode"];
		}
		if( empty($retobj) ){
			$sErrmsg = '网络异常sendCustomerServiceMsg';
			p_file('网络异常:sendCustomerServiceMsg');
			return 1;
		}
		return 0;		
	}
	
	
	/**
	 * 上传临时素材
	 * 上传图片，本接口所上传的图片不占用公众号的素材库中图片数量的5000个的限制。图片仅支持jpg/png格式，大小必须在1MB以下。 (认证后的订阅号可用)
	 * 注意：上传大文件时可能需要先调用 set_time_limit(0) 避免超时
	 * 注意：数组的键值任意，但文件名前必须加@，使用单引号以避免本地路径斜杠被转义
	 * @param array $data {"media":'@Path\filename.jpg'}
	 *
	 * @return 0表示成功   非0是错语代码
	 */
	public function uploadMedia($data,$mediatype,&$mediaid,&$errMsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errMsg);
		if ($ret != 0)
		{
			p_file('上传临时素材，获取access_token失败：'.$errMsg);
			return $ret;
		}
		//原先的上传多媒体文件接口使用 self::UPLOAD_MEDIA_URL 前缀
		$purl="https://api.weixin.qq.com/cgi-bin/media/upload?access_token=".$saccessToken."&type=".$mediatype;
		$result = HttpUtil::http_post($purl,$data,true);
		$json = json_decode($result,true);;
		//注意用[]方式读取数据，否则返回不正确
		if (!empty($json['errcode'])) {
			$errMsg = $json['errmsg'];
			p_file('客服上传临时素材json='.json_encode($json));
			return ($json['errcode']?$json['errcode']:'1');
		}
		if( empty($json) ){
			$errMsg = '网络异常uploadMedia';
			p_file('网络异常:uploadMedia');
			return 1;
		}
		else
		{
			$mediaid = $json['media_id'];
			return 0;
		}
	}
		
	/**
	 * 将指定URL中的图片上传为临时素材并产生mediaid
	 * @param string $msgtype
	 * @param unknown $imageurl
	 * @param unknown $filename
	 * @param unknown $mediaid
	 * @param unknown $errMsg
	 * @return Ambigous <\Common\Lib\WeiXin\0表示成功, number, mixed, \Common\Lib\WeiXin\0>
	 */
	public function urlImageToWxMedia($msgtype,$imageurl,$filename,&$mediaid,&$errMsg)
	{
		$tempdir = getcwd().'/temp/'.$this->m_comp_id.'/'.uniqid();
		if (!file_exists($tempdir))
		{
			$result = mkdir($tempdir,0777,true);
			if($result === false)
			{
				p_file("目录创建失败");
			}
		}
		$fullfilename = $tempdir.'/'.$filename.'.jpg';
		$type = "setopt";
		$res = ImageFuncUtil::downRemoteFile($imageurl, $fullfilename, $errMsg,$type);
		if($res === false)
		{
			p_file('远程获取图片失败:'.$errMsg);
		}
		$logodata=array(
				"media"=>'@'.$fullfilename
		);
		$logret = $this->uploadMedia($logodata,$msgtype,$mediaid,$errMsg);
		@unlink($fullfilename);
		return 	$logret;
	}
}

