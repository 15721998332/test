<?php
namespace Common\Lib\WeiXin;

use Common\Lib\HttpUtil;
use Common\Lib\SysCacheMgr;
use Common\Lib\WeiXin\Lib\ErrorCode;
use Common\Lib\WeiXin\Lib\Prpcrypt;
use Common\Lib\WeiXin\Lib\SHA1;
use Common\Lib\WeiXin\Lib\XMLParse;
use Common\Lib\WeiXin\Lib\WXBizMsgCrypt;
use Common\Lib\FuncUtils\ImageFuncUtil;

/**
 * 微信接口开发的SDK.
 *
 * @copyright Copyright (c) 1998-2014 Tencent Inc.
 */

/**
 * 1.getAccessToken				获取AccessToken；
 * 2.sendTransToCustomServiceMessage	转发给客服接管
 * 2.sendTextMessage			发送文本信息
 * 3.sendNewsMessage			发送图文消息
 * 4.getAuthorizeCode			获取网页授权读取用户openid
 * 5.getJsApiTicket				生成微信JS接口的临时票据
 * 6.getUserInfo				获取微信用户信息
 * 7.createQrcodeFixTicket		创建一个固定的二维码
 * 8.uploadImg					上传一个图片
 * 9.createCard					创建卡券
 * 10.getCardSign				得到卡签名
 * 11.getApiTicket				生成微信api接口的临时票据
 * 12.getCacheData				读取缓存数据()
 * 13.setCacheData				设置缓存数据()
 * 14.sendTemplateMessage		发送模板消息
 * 15.verifyURL					验证URL
 * 16.encryptMsg				将公众平台回复用户的消息加密打包
 * 17.decryptMsg				检验消息的真实性，并且获取解密后的明文
 * 18.downloadTemplate			下载消息模板
 * 
 * 25.sendCustomerServiceMsg	发送客户服务回复消息
 */
class WXMinSdk
{
// 	private $m_compmd5;				//用于标识公司号的唯一ID，位于URL的company参数中，暂时是Md5(公司代码)的值
// 	private $m_sToken;				//微信对接token
// 	private $m_sEncodingAesKey;		//微信对接验证的key值secretkey
	private $mi_appid;				//微信对接的公众号开发ID
	private $mi_appsecret;			//微信对接的开发密accesstoken
	private $mi_cropid;				//微信公众号的原始ID
	private $mi_compid;				//公司的id
// 	private $wxthirdauth;			//是否使用第三方授权
// 	private $wxthirdastatus;		//第三方授权状态
// 	private $msgcrypt;				//是否加密
// 	private $m_setup_id;			//公众号ID
	
	/**
	 * 构造函数
	 * 从配置文件中读取微信相关设置属性
	 */
	function __construct($comp_id)
	{
// 		$mini = SysCacheMgr::getMinProgSetUp($mini_id);
		$mini = M("vip_minprog_setup")->field("app_id,app_secret,cropid,is_third")->where(array("comp_id"=>$comp_id))->find();
		
// 		$company = SysCacheMgr::getcompanybyweixinid($compmd5id);
// 		$this->m_sToken = $company["mp_token"];
// 		$this->m_sEncodingAesKey = $company["mp_encodingaeskey"];
		$this->mi_appid = $mini["app_id"];
		$this->mi_cropid = $mini["cropid"];
		$this->mi_appsecret = $mini["app_secret"];
		$this->mi_compid = $comp_id;
		$this->is_third = $mini["is_third"];
// 		$this->m_comp_id = $company["comp_id"];
// 		$this->wxthirdauth = $company["wxthirdauth"];
// 		$this->wxthirdastatus = $company["wxthirdastatus"];
// 		$this->msgcrypt = $company["msgcrypt"];
// 		$this->m_setup_id = $company["setup_id"];
	}

	
	/**
	 * @return the $mi_appid
	 */
	public function getMi_appid() {
		return $this->mi_appid;
	}

	/**
	 * @return the $m_appsecret
	 */
// 	public function getM_appsecret() {
// 		return $this->m_appsecret;
// 	}

	/**
	 * @return the $m_cropid
	 */
// 	public function getM_cropid() {
// 		return $this->m_cropid;
// 	}
	
	/**
	 * @return the $m_setup_id
	 */
// 	public function getM_seupid() {
// 		return $this->m_setup_id;
// 	}
	
	/**
	 * 获取AccessToken,根据失效时间暂存起来,兼容第三方授权，如果为第三方授权，则采用app_auth_token【authorizer_access_token】
	 * 由于当AccessToken缓存失效时，并发的多个连接将会是时访问，可能刷新了几个不同的AccessToken，从而可能出现后刷新的AccessToken被其它链接刷失效
	 * 解决并发的方法：
	 * 1、缓存AccessToken的同时，按返回的失效时间备份缓存另外一份AccessToken；
	 * 2、在任何一个进程调用函数刷新AccessToken时，在缓存中记录已开启刷新的标识，该标识10秒后自动失效；
	 * 3、刷新标识在生效时，从备份缓存中读取AccessToken使用；
	 * @param String $accessToken
	 * @param String $sErrmsg
	 * @return 0 成功，非0失败
	 */
	public function getAccessToken(&$accessToken,&$errmsg)
	{
		if($this->is_third=='Y')
		{
			$authtoken = M('authtoken')->field('auth_app_id,app_auth_token,app_refresh_token,expires_date')->where(array('comp_id'=>$this->mi_compid,'auth_app_id'=>$this->getMi_appid()))->find();
			if(empty($authtoken)){
				$errmsg = '读取token失败';
				return 1;
			}else{
				$accessToken = $authtoken['app_auth_token'];
				return  0;
			}
		}
		
		
		$token = M("weixin_token")->field('tokenvalue,expiredate,lastdate,errmsg')->where(array('appid'=>$this->getMi_appid(),'tokentype'=>'accesstoken'))->find();
		if(empty($token)){
			$errmsg = '读取token失败';
			return 1;
		}else{
			$accessToken = $token['tokenvalue'];
			return  0;
		} 

	}

	

	
	
	/**
	 * 读取指定类型的缓存数据
	 * @param  string $cachedatatype	缓存数据类型
	 * 							mp_accesstoken		微信公众号缓存
	 * 							mp_jsapiticket			jsapi临时票据缓存
	 * 							mp_apiticket			api临时票据缓存
	 * 							compoment_accesstoken	公众号第三方授权缓存
	 */
	private function getCacheData($cachedatatype)
	{
		$catch_name = strtoupper($cachedatatype)."_".strtoupper($this->m_compid);
		return S($catch_name);
	}
	
	/**
	 * 设置缓存数据
	 * @param string $cachedatatype 缓存数据类型
	 * 							mp_accesstoken		微信公众号缓存
	 * 							mp_jsapiticket			jsapi临时票据缓存
	 * 							mp_apiticket			api临时票据缓存 
	 * 							compoment_accesstoken	公众号第三方授权缓存
	 * @param array $cachedata
	 * @param int $expire
	 * @return true / false
	 */
	private function setCacheData($cachedatatype,$cachedata,$expire)
	{
		$catch_name = strtoupper($cachedatatype)."_".strtoupper($this->m_compid);
		$result = S($catch_name,$cachedata,$expire);
		if (!$result)
		{
			p_file("缓存".$catch_name."的值".$cachedata."失败");
		}
		if (strtoupper($cachedatatype) == strtoupper("mp_accesstoken") || strtoupper($cachedatatype) == strtoupper("compoment_accesstoken"))	//如果accesstoken失效，则将jsapiticket，apiticket一起失效
		{
			p_file('setCachedata:'.$catch_name);
			$jsapiticket = strtoupper("mp_jsapiticket")."_".strtoupper($this->m_compid);
			S($jsapiticket,null);
			$apiticket = strtoupper("mp_apiticket")."_".strtoupper($this->m_compid);
			S($apiticket,null);			
		}
		return $result;
	}
	
	
	/**
	 * 清除缓存数据
	 * @param string $cachedatatype 缓存数据类型
	 * 							mp_accesstoken		微信公众号缓存
	 * 							mp_jsapiticket			jsapi临时票据缓存
	 * 							mp_apiticket			api临时票据缓存
	 * 							compoment_accesstoken	公众号第三方授权缓存
	 */
	public function resetCacheData($cachedatatype)
	{
		$catch_name = strtoupper($cachedatatype)."_".strtoupper($this->m_compid);
		S($catch_name,null);
		if (strtoupper($cachedatatype) == strtoupper("mp_accesstoken") || strtoupper($cachedatatype) == strtoupper("compoment_accesstoken"))	//如果accesstoken失效，则将jsapiticket，apiticket一起失效
		{
			$jsapiticket = strtoupper("mp_jsapiticket")."_".strtoupper($this->m_compid);
			S($jsapiticket,null);
			$apiticket = strtoupper("mp_apiticket")."_".strtoupper($this->m_compid);
			S($apiticket,null);
		}
	}
	
	
	/**
	 *  添加模版消息到模版库 
	 */
	public function addMiniMsgTemplate($msg_id,array $fieldslist,&$templ_id,&$sErrMsg)
	{
	
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$sErrMsg);
		if ($ret != 0)
		{
			return $ret;
		}
		$message = array(
				"id"=>$msg_id,
				"keyword_id_list"=>$fieldslist
		);
	
		$data = json_encode($message,JSON_UNESCAPED_UNICODE);
		$jsondata = HttpUtil::https_post("https://api.weixin.qq.com/cgi-bin/wxopen/template/add?access_token=".$saccessToken,$data);
		$json = json_decode($jsondata);
		if (!empty($json->errcode) || empty($json))
		{
			$sErrMsg = $json->errmsg;
			p_file("wxsdk中downloadTemplate出错:");
			p_file("出错明细:".$jsondata);
			return $json->errcode;
		}
		if( empty($json) ){
			$sErrmsg = '网络异常downloadTemplate';
			p_file('网络异常:downloadTemplate');
			return 1;
		}
		$templ_id = $json->template_id;
		return 0;
	}
		
	
	/**
	 * 发送小程序模板消息
	 * @param array $message		消息内容
	 * @param int  $iMsgid			返回的消息号
	 * @param string $sErrmsg		返回的错误文本
	 * @return 返回errcode 0表示成功，非0表示失败
	 */
	public function sendMiniTemplateMsg(array $message,&$iMsgid,& $errmsg)
	{
		//得到accessToken
		$saccessToken="";
		$ret = $this->getAccessToken($saccessToken,$errmsg);
		if ($ret != 0)
		{
			return $ret;
		}
	
		//转换为json,并且不能转为unicode
		$data = json_encode($message,JSON_UNESCAPED_UNICODE);
	
		//调用发送接口
		$jsondata = HttpUtil::https_post("https://api.weixin.qq.com/cgi-bin/message/wxopen/template/send?access_token=".$saccessToken,$data);
		$retobj = json_decode($jsondata,true);
		if ($retobj["errcode"] != "0")
		{
			$errmsg = $retobj["errmsg"];
			p_file("wxsdk中sendMiniTemplateMsg出错:");
			p_file("出错明细:".$jsondata);
			return $retobj["errcode"];
		}
		if( empty($retobj) ){
			$errmsg = '网络异常sendMiniTemplateMsg';
			p_file('网络异常:sendTemplateMsg');
			return 1;
		}
		$iMsgid = $retobj["msgid"];
		return 0;
	}
	
	
	
	
	
	
	
	
	
	
}

