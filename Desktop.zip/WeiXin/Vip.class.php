<?php
namespace Common\Lib\WeiXin;
class Vip{
	
	public static function formatVipInfoFields($compid,$infofields,&$subset1,&$subset2,&$subset3){
		
		$arrs = array();
		foreach ($infofields as $k => $v){
			$suarr = array();
			$suarr['val'] = $v;
			if($k=='email'){
				$suarr['type'] = 'email';
			}elseif($k=='birthday' || $k=='otherdate1' || $k=='otherdate2'){
				$suarr['type'] = 'birthday';
			}elseif($k=='sex' || $k=='othersex1' || $k=='othersex2'){
				$suarr['type'] = 'sex';
			}else{
				$suarr['type'] = 'text';
			}
			$arrs[$k] = $suarr;
		}
		
		$subset1 = array_slice($arrs, 0,5);
		$subset2 = array_slice($arrs, 5,4);
		$subset3 = array_slice($arrs, 9,6);
		
		$subset1['vip_name']['txt'] = '姓名';
		$subset1['sex']['txt'] = '性别';
		$subset1['birthday']['txt'] = '生日';
		$subset1['tel']['txt'] = '电话';
		$subset1['email']['txt'] = 'email';
		
		
		$subset2['state']['txt'] = '省份';
		$subset2['city']['txt'] = '城市';
		$subset2['district']['txt'] = '县区';
		$subset2['address']['txt'] = '地址';
		
		foreach ($subset3 as $k=>$v){
			$txt= getsyscodename($compid, "fieldname_alias","t_vip_".$k);
			if(empty($txt)){
				if($k=='othername1'){
					$txt='成员1姓名';
				}
				if($k=='othername2'){
					$txt='成员2姓名';
				}
				if($k=='othersex1'){
					$txt='成员1性别';
				}
				if($k=='othersex2'){
					$txt='成员2性别';
				}
				if($k=='otherdate1'){
					$txt='成员1生日';
				}
				if($k=='otherdate2'){
					$txt='成员2生日';
				}
			}
			$subset3[$k]['txt'] = $txt;
		}
		
		return true;
	}
	
}