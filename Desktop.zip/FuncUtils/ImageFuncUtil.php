<?php
namespace FuncUtils;

use FuncUtils\UploadFileUtil;
use FuncUtils\UploadImgUtil;
use think\Image;
use MallUtils\MallFuncUtil;
use Common\Lib\WeiXin\Vip;

/**
 * 图片保存与读取等相关功能类
 * 1.uploadImage			上传保存图片
 * 2.getImageUrl			得到指定图片的路径
 * 3.getImageName			得到指定图片的名称
 * 4.downRemoteFile			下载远程文件
 * @author Administrator
 * 
 */
class ImageFuncUtil {
	
	/**
	 * 上传煤体表t_data_pic
	 * @param int $compid
	 * @param String $datatype
	 * @param String $datanum
	 * @param String $datafield
	 * @param String $opername
	 * @param String &$errmsg	引用方式，返回错误信息
	 * @return
	 * 		成功时返回： array(
	 * 			"picurl":图片存放路径
	 * 			"picname":图片名称
	 * 		)
	 * 		失败时返回：false
	 */
	public static function uploadMedia($compid,$datatype,$datanum,$datafield,$opername,&$errmsg)
	{
		$returndata = array();
		$upload = new UploadFileUtil($compid);
		$info = $upload->uploadFileOne(strtoupper($datatype),array("mp3","mp4","wma","amr","wav"));
		if ($info == false)
		{
			$errmsg = $upload->getErrmsg();
			return false;
		}
		else
		{
			$returndata["picurl"]=$info["savepath"].$info["savename"];
			$returndata["picname"]=$info["name"];
			//读入数据
			$model = M("pic_data");
			$piccount = $model->where(array("comp_id"=>$compid,"data_type"=>$datatype,"data_num"=>$datanum,"data_field"=>$datafield))
			->count();
			if ($piccount > 0)
			{
	
				$data = array(
						"image_url"=>$info["savepath"].$info["savename"],
						"image_name"=>$info["name"],
						"createdate"=>getdatetime(time()),
						"createname"=>$opername
				);
				$ret = $model->where(array("comp_id"=>$compid,"data_type"=>$datatype,"data_num"=>$datanum,"data_field"=>$datafield))->save($data);
			}
			else
			{
				$data = array(
						"comp_id"=>$compid,
						"data_type"=>$datatype,
						"data_num"=>$datanum,
						"data_field"=>$datafield,
						"image_url"=>$info["savepath"].$info["savename"],
						"image_name"=>$info["name"],
						"createdate"=>getdatetime(time()),
						"createname"=>$opername
				);
				$ret = $model->add($data);
			}
			if ($ret === false)
			{
				$errmsg = getDbError();
				return false;
			}
		}
		return $returndata;
	}
	
	
	/**
	 * 上传图片到通用图片表t_data_pic
	 * @param int $compid
	 * @param String $datatype
	 * @param String $datanum
	 * @param String $datafield
	 * @param String $opername
	 * @param String &$errmsg	引用方式，返回错误信息
	 * @return 
	 * 		成功时返回： array(
	 * 			"picurl":图片存放路径
	 * 			"picname":图片名称
	 * 		) 
	 * 		失败时返回：false
	 */
	public static function uploadImage($openid,$datanum,&$errmsg)
	{
		$returndata = array();
		//改为cos存储
		$upload = new UploadImgUtil();
// 		$upload = new UploadFileUtil($compid);
		$info = $upload->uploadFileOne(strtoupper(time()),array("jpg","png","jpeg"));
		if ($info == false)
		{
			
			return false;
		}
		else
		{
			$returndata["picurl"]=$info["savepath"].$info["savename"];
			$returndata["picname"]=$info["name"];
			$returndata["savename"]=$info["savename"];
			//读入数据
			$model = M("img_data");
			$piccount = $model->where(array("data_num"=>$datanum))
			->count();
			if ($piccount > 0)
			{
				
				$data = array(
						"img_url"=>$info["savepath"].$info["savename"],
						"image_name"=>$info["name"],
						"lasdata"=>getdatetime(time()),
				);
				$ret = $model->where(array("data_num"=>$datanum))->save($data);
			}
			else
			{
				$data = array(
						"data_num"=>$datanum,
						'openid'=>$openid,
						"img_url"=>$info["savepath"].$info["savename"],
						"lasdata"=>getdatetime(time())
				);
				$ret = $model->add($data);
			}
			if ($ret === false)
			{
				$errmsg = getDbError();
				return false;
			}
		}
		$returndata['id']=$ret;
		return $returndata;
	}
	
	/**
	 * 上传图片到通用图片表t_data_pic
	 * @param int $compid
	 * @param String $datatype
	 * @param String $datanum
	 * @param String $datafield
	 * @param String $opername
	 * @param String &$errmsg	引用方式，返回错误信息
	 * @return
	 * 		成功时返回： array(
	 * 			"picurl":图片存放路径
	 * 			"picname":图片名称
	 * 		)
	 * 		失败时返回：false
	 */
	public static function uploadVideoCover($datatype,$datanum,$datafield,$filename,$opername,&$errmsg)
	{
		$returndata = array();
		$upload = new UploadFileUtil('qsgs');
		$info = $upload->uploadFileOne(strtoupper($datatype),array("jpg","png","gif","jpeg","mp4"));
		if ($info == false)
		{
			$errmsg = $upload->getErrmsg();
			return false;
		}
		else
		{
			$returndata["picurl"]=$info["rootpath"].$info["savepath"].$info["savename"];
			$returndata["picurlpath"]=$info["rootpath"].$info["savepath"];
			$returndata["picname"]=$info["name"];
p_file('视频'.json_encode($returndata));
		}
		
		$video_w = getVar('width');
		$video_h = getVar('height');
		
		$video_cover = getVideoCover( $returndata['picurl'],2,$video_w,$video_h);
		$upload = new UploadImgUtil('qsgs');
		p_file($returndata['picurlpath'].$video_cover);
		$img_info = $upload->TransferFileOne($returndata['picurlpath'].$video_cover,strtoupper($datatype),$filename,'jpg',array("jpg","png","gif","jpeg"));
		
		if ($img_info == false)
		{
			$errmsg = $upload->getErrmsg();
			return false;
		}
		else
		{
			$returndata["picurl"]=$img_info["savepath"].$img_info["savename"];
			$returndata["picname"]=$img_info["name"];
			//读入数据
			$model = M("pic_data");
			$piccount = $model->where(array("data_type"=>$datatype,"data_num"=>$datanum,"data_field"=>$datafield))->count();
			if ($piccount > 0){
		
				$data = array(
						"first_image_url"=>$img_info["savepath"].$img_info["savename"],
				);
				$ret = $model->where(array("data_type"=>$datatype,"data_num"=>$datanum,"data_field"=>$datafield))->save($data);
				
				if ($ret === false)
				{
					$errmsg = getDbError();
					return false;
				}
				
			}else{
				$errmsg = '更新封面失败';
				return false;
			}
			
		
		}
		return $returndata;
	}

	

	/**
	 * 读取指定图片的路径
	 * @param int $compid
	 * @param String $datatype
	 * @param String $datanum
	 * @param String $datafield
	 * @return  图片路径
	 */
	public static function getImageUrl($datatype,$datanum,$datafield)
	{
		$model = M("pic_data");
		$picdata = $model->where(array("data_type"=>$datatype,"data_num"=>$datanum,"data_field"=>$datafield))
			->find();
		if (!$picdata)
		{
			return "";
		}
		else
		{
			return $picdata["image_url"];
		}
	}
	
	/**
	 * 读取指定图片的文件名
	 * @param int $compid
	 * @param String $datatype
	 * @param String $datanum
	 * @param String $datafield
	 * @return  图片路径
	 */
	public static function getImageName($compid,$datatype,$datanum,$datafield)
	{
		$model = M("pic_data");
		$picdata = $model->where(array("comp_id"=>$compid,"data_type"=>$datatype,"data_num"=>$datanum,"data_field"=>$datafield))
		->find();
		if (!$picdata)
		{
			return "";
		}
		else
		{
			return $picdata["image_name"];
		}
	}
	
	/**
	 * 读取指定大小的图片的路径
	 * @param int $compid
	 * @param String $datatype
	 * @param String $datanum
	 * @param String $datafield
	 * @param int $width
	 * @param int $legnth
	 * @return  图片路径
	 */
	public static function getImageUrlBySize($compid,$datatype,$datanum,$datafield,$width,$length)
	{
		
		$model = M("pic_data");
		$picdata = $model->where(array("comp_id"=>$compid,"data_type"=>$datatype,"data_num"=>$datanum,"data_field"=>$datafield))
				->find();
		if (!$picdata)
		{
			return "";
		}
		//原图文件
		$imgurl = $picdata["image_url"];
		//按规则转换为相应尺寸的文件名
		$imgTypeArr = explode(".",$imgurl);
		$sizeImgUrl = $imgTypeArr[0].'_'.intval($width)."_".intval($length).".".$imgTypeArr[1];
		
		$checkurl = './Public/uploads/'.$sizeImgUrl;
		$checkOrgUrl='./Public/uploads/'.$imgurl;
		
		if(!file_exists($checkurl) && file_exists($checkOrgUrl))
		{
			$image = new \Think\Image();
			$image->open($checkOrgUrl);
			$image->thumb(intval($width),intval($length))->save($checkurl);
		}
		
		return $sizeImgUrl;
	}
	
	/**
	 * downRemoteFile
	 * @param string $remoteurl  远程路径
	 * @param string $fullfilename	保存文件名(含路径)
	 * @param string $errMsg   错误消息
	 * @return true / false
	 */
	public static function downRemoteFile($remoteurl,$fullfilename,&$errMsg,$type='')
	{

		try
		{
			
			if(ini_get("allow_url_fopen") == "1" && $type=='')
			{
				$fp = file_get_contents($remoteurl);
			}
			else if($type == "setopt")
			{
				$ch = curl_init();
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
				curl_setopt($ch, CURLOPT_URL,$remoteurl);
				$fp = curl_exec($ch);
				curl_close($ch);
			} 
			$len = strlen($fp);
			if ($len > 0)
			{
				file_put_contents($fullfilename,$fp);
			}
			else
			{
				return false;
			}
			
			return true;
		}
		catch (\Exception $e1)
		{
			$errMsg = $e1->getMessage();
			return false;
		}
	}
	
	/**
	 * textToImg
	 * @param string $bigImgPath  远程路径
	 * @param string $content	     添加文本内容
	 * @return true / false
	 */
	public static function textToImg($bigImgPath,$content)
	{   
		ob_clean();
		$img = imagecreatefromstring(file_get_contents($bigImgPath));
		
		list($qCodeWidth, $qCodeHight, $qCodeType) = getimagesize($bigImgPath);
		
		$im = imagecreatetruecolor($qCodeWidth, $qCodeHight+50);
		
		$white = imagecolorallocate($im, 255, 255, 255);
		imagefilledrectangle($im, 0, 0, $qCodeWidth, $qCodeHight+50, $white);
		
		imagecopymerge($im, $img, 0, 0, 0, 0, $qCodeWidth, $qCodeHight, 100);
		
		$text = $content;
		$font = 'C:/Windows/Fonts/simkai.ttf';//字体
		$black = imagecolorallocate($im, 0xcc,0x40,0x00);//字体颜色 RGB
		$fontSize = 20;   //字体大小
		$circleSize = 0; //旋转角度
		$left = 50;      //左边距
		$top = $qCodeHight;       //顶边距
		
		$fontBox = imagettfbbox($fontSize, 0, $font, $text);
		
		imagettftext($im, $fontSize, $circleSize, ceil(($qCodeWidth - $fontBox[2]) / 2), $top, $black, $font, $text);
		$result = false;
		switch ($qCodeType) {
			case 1: //gif
				//header('Content-Type:image/gif');
				$result = imagegif($im,$bigImgPath);
				break;
			case 2: //jpg
				//header('Content-Type:image/jpg');
				$result = imagejpeg($im,$bigImgPath);
				break;
			case 3: //jpg
				//header('Content-Type:image/png');
				$result = imagepng($im,$bigImgPath);
				break;
			default:
				break;
		}
		imagedestroy($im);
		imagedestroy($img);
		return $result;
	}
	
	
	
	/**
	 * 读取指定比率大小的图片的路径
	 * @param int $compid
	 * @param String $datatype
	 * @param String $datanum
	 * @param String $datafield
	 * @param int $width
	 * @param int $legnth
	 * @param int $ratio 	(1~10正整数)
	 * @return  图片路径
	 */
	public static function getImageUrlByRatioSize($compid,$datatype,$datanum,$datafield,$ratio)
	{
	
		$model = M("pic_data");
		$picdata = $model->where(array("comp_id"=>$compid,"data_type"=>$datatype,"data_num"=>$datanum,"data_field"=>$datafield))
		->find();
		if (!$picdata)
		{
			return "";
		}
		//原图文件
		$imgurl = $picdata["image_url"];
		//按规则转换为相应尺寸的文件名
		$imgTypeArr = explode(".",$imgurl);
		$sizeImgUrl = $imgTypeArr[0].'_'.intval($ratio).".".$imgTypeArr[1];
	
		$checkurl = './Public/uploads/'.$sizeImgUrl;
		$checkOrgUrl='./Public/uploads/'.$imgurl;
	
		if(!file_exists($checkurl) && file_exists($checkOrgUrl))
		{
			$image = new \Think\Image();
			$image->open($checkOrgUrl);
			
			$width = $image->width(); // 返回图片的宽度
			$height = $image->height(); // 返回图片的高度
			
			$new_width = ($width * $ratio)/10;
			$new_height = ($height * $ratio)/10;
			
			$image->thumb(intval($new_width),intval($new_height))->save($checkurl);
		}
	
		return $sizeImgUrl;
	}
	/**
	 * 图像圆图的处理
	 * @param int $compid
	 * @param String $imgpath 图片路径
	 * @param String $data_type 
	 * @param String $data_num 
	 * @param String $data_field 
	 * @param String $opername 用户名
	 * @param String $radius 圆角值，为空时默认为圆角
	 * @param $errmsg
	 * 
	 * @return  图片路径
	 */
	public static function uploadRadiusImg($compid,$imgpath,$data_type,$data_num,$data_field,$opername='wx',$radius='',&$errmsg){
		if(empty($data_type) || empty($data_num) || empty($data_field)){
			$errmsg='缺少参数';
			return false;
		}
		if(empty($imgpath)){
			$errmsg='图片地址不能为空';
			return false;
		}
// 		if(!file_exists($imgpath)){
// 			$errmsg='图片不存在';
// 			return false;
// 		}
		$filesize = @getimagesize($imgpath);
		if (!$filesize) {
			$errmsg='图片不存在';
			return false;
		}
		$upload = new UploadImgUtil($compid);
		//将图片转换成圆角
		$radius_url=Image::radius_img($imgpath,$radius,$errmsg);
		if($radius_url==false){
			return false;
		}
		//拼接随机图片名
		$imgname=MallFuncUtil::makeBillno();
		$imgnames=$imgname.'.png';
		imagepng($radius_url, $imgnames);
		
		$img_info = $upload->TransferFileOne($imgnames,'radius',$imgname,'png',array("jpg","png","gif","jpeg"));
		if($img_info==false){
			return false;
		}
		$image_url=$img_info['savepath'].$img_info['savename'];
		$data = array(
			"comp_id"=>$compid,
			"data_type"=>$data_type,
			"data_num"=>$data_num,
			"data_field"=>$data_field,
			"image_url"=>$image_url,
			"image_name"=>$imgnames,
			"createdate"=>getdatetime(time()),
			"createname"=>$opername
		);
		
		$ret = M('pic_data')->add($data);
		if($ret===false){
			p_file('转换圆角时图片保存出错'.getDbError());
			$errmsg='转换圆角时图片保存出错'.getDbError();
			return false;
		}
		//删除临时图片
		$ret=unlink($imgnames);
		if($ret==false){
			p_file('删除临时图片'.$imgnames);
		}
		return $image_url;
	}
	/**
	 * 海报二维码
	 * @param int $compid
	 * @param int $vip_id 会员id
	 * @param String $data_type qrcode
	 * @param String $data_field 邀请家长:invite_parent。邀请老师:invite_headmaster
	 * @param String $qrcode 二维码路径
	 * @param String $headimg 头像路径
	 * @param String $name 如果是老师：会员名+老师 ，如果是家长孩子名+关系
	 * @param String $class 班级名称
	 * @param String $bigImgPath 背景图路径
	 * @param $errmsg
	 *
	 * @return  图片路径
	 */
	public static function posterQrcode($data_type,$data_field,$vip_id,$qrcode,$headimg,$name,$content,$newSignature,$tem,$wea,$image,$city,&$errmsg=''){
		//背景图start
		ob_clean();
		$img = imagecreatefromstring(file_get_contents($image));//从文件或 URL 载入一幅图像，成功返回图像资源，失败则返回一个空字符串。
		if(empty($img)){
			$errmsg='载入图片失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
	
		list($qCodeWidth, $qCodeHight, $qCodeType) = getimagesize($image);//获取图片的宽\高\类型
	
		$im = imagecreatetruecolor($qCodeWidth, $qCodeHight);//按原图创建一块黑色画布
		if($im==false){
			$errmsg='创建黑色画布失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		$ret=imagecopymerge($im, $img, 0, 0, 0, 0, $qCodeWidth, $qCodeHight, 100);//将图片与创建的矩形合并
		if($ret==false){
			$errmsg='图片与创建的矩形合并失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		//end
	
		//创建需要的临时图片start
		$rand=rand(100, 999);
		$imgurl=$data_field.$vip_id.$rand.'.png';//拼接海报图片路径
		$imgname=$data_field.$vip_id.$rand;
		
	
		//创建二维码图片
		$qrcode = imagecreatefromjpeg($qrcode);//创建一个新图片载入二维码
		if($qrcode==false){
			$errmsg='二维码图片创建失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		//创建需要的临时图片end
	
		$font = 'fonts/simkai.ttf';//字体
		$black=imagecolorallocate($im,255, 255, 255);
		$class_px=28;
		$result=imagettftext($im,$class_px,0,60,209,$black,$font,$city);//209px
		if($result==false){
			$errmsg='将城市放到背景图失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		$box=imagettfbbox($class_px, 0, $font, $city);//根据字体计算字体所占的宽度
		$city_width = $box[4] - $box[6];//计算字体所占的宽度209px
		$result=imagettftext($im,$class_px,0,$city_width+80,209,$black,$font,$tem);
		if($result==false){
			$errmsg='将温度放到背景图失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		$box=imagettfbbox($class_px, 0, $font, $tem);//根据字体计算字体所占的宽度
		$tem_width = $box[4] - $box[6];//计算字体所占的宽度209px
		$result=imagettftext($im,$class_px,0,$city_width+100+$tem_width,209,$black,$font,$wea);
		if($result==false){
			$errmsg='将天气放到背景图失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		
		
		$lineTextLen=17;
		$length=mb_strlen($content,'UTF-8');
		$lineNum=ceil($length/$lineTextLen);
		$end=17;
		for ($i=0;$i<$lineNum;$i++){
			$start=$i*17;
			$text=mb_substr($content,$start,17,'UTF-8');
			$hight=359+$i*60;
			imagettftext($im,$class_px,0,60,$hight,$black,$font,$text);
		}
// 		$result=imagettftext($im,$class_px,0,60,'359px',$black,$font,$content);.'px'
		if($result==false){
			$errmsg='将文字放到背景图失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		//头像
		$url=substr($headimg, 0, -3);
		$headimg=$url.'64';
		//头像将图片转换成圆角
        $Image=new Image();
		$radius_url=$Image->radius_img($headimg,'',$errmsg);
		if($radius_url==false){
			return false;
		}
		$avaturlh=$hight>753?$hight+41:800;
		$result=imagecopy($im, $radius_url, 60, $avaturlh, 0, 0, 64, 64);//."px"
		if($result==false){
			$errmsg='将头像放到背景图失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		$len=mb_strlen($newSignature,'UTF-8');
		if($len<=13){
			$result=imagettftext($im,$class_px,0,160,($avaturlh+42),$black,$font,'— '.$newSignature);//.'px'
			$code=$avaturlh+42;
		}else {
			$text=mb_substr($newSignature,0,13,'UTF-8');
			$texta=mb_substr($newSignature,13,17,'UTF-8');
			$result=imagettftext($im,$class_px,0,160,($avaturlh+42),$black,$font,'— '.$text);//.'px'
			$result=imagettftext($im,$class_px,0,60,($avaturlh+102),$black,$font,$texta);//.'px'
			$code=$avaturlh+102;
		}
		if($result==false){
			$errmsg='将签名放到背景图失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		
		
		$result=imagecopy($im, $qrcode, 550, 1150, 0, 0, 132, 132);//px"
		if($result==false){
			$errmsg='将二维码放到背景图失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
// 		$result=imagettftext($im,20,0,320,($code+68+56+132).'px',$black,$font,'长按识别');
// 		//创建图片
		$result = imagepng($im, $imgurl);
		if($result==false){
			$errmsg='背景图片创建失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
	
		//将图片上传腾讯云start
		$upload = new UploadImgUtil('tools');
		$img_info = $upload->TransferFileOne($imgurl,$data_field,$imgname,'png',array("jpg","png","gif","jpeg"));//将图片上传
		if($img_info==false){
			unlink($imgurl);
			$errmsg='上传图片失败';
			$res=array(
					'success'=>-1,
					'msg'=>$errmsg
			);
			return $res;
		}
		$image_url='https://demo-1256311631.picgz.myqcloud.com/Public/uploads/'.$img_info['savepath'].$img_info['savename'];
		unlink($imgurl);
		$res=array(
			'success'=>1,
			'image_url'=>$image_url
		);
		return $res;
	
	}
}

?>