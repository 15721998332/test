<?php
namespace Common\Lib\FuncUtils;

/**
 * 文件操作等相关功能类
 * @author Administrator
 * 
 */
class FileFuncUtil {

	/**
	 * 下载指定文件
	 * @param unknown $filename
	 */
	public static function downFile($filename)
	{
		header("Cache-Control: public");
		header("Content-Type: application/force-download");
		header("Content-Type: application/octet-stream");
		header("Content-Type: application/download");		
		header("Content-Description: File Transfer");
		header('Content-disposition: attachment; filename='.basename($filename)); //文件名
		header("Content-Type: application/zip"); //zip格式的
		header("Content-Transfer-Encoding: binary"); //告诉浏览器，这是二进制文件
		header('Content-Length: '. filesize($filename)); //告诉浏览器，文件大小
		@readfile($filename);
	}
	
	/**
	 * 将目录压缩成文件
	 * @param unknown $srcpath
	 * @param unknown $zipfilename
	 */
	public static function zipFolderToFile($srcpath,$zipfilename)
	{
		$zip=new \ZipArchive();
		if($zip->open($zipfilename, \ZipArchive::CREATE)=== TRUE){
			self::addFileToZip($srcpath,$zip); //调用方法，对要打包的根目录进行操作，并将ZipArchive的对象传递给方法
			$zip->close(); //关闭处理的zip文件
		}
	}
	
	/**
	 * 增加压缩文件 
	 * @param unknown $path	需要压缩的文件
	 * @param unknown $zip	压缩文件名
	 * @param string $basepath	在压缩文件中的相对目录
	 */
	private static function addFileToZip($path,$zip,$basepath="")
	{
		$handler=opendir($path); //打开当前文件夹由$path指定。
		while(($filename=readdir($handler))!==false){
			if($filename != "." && $filename != ".."){//文件夹文件名字为'.'和‘..’，不要对他们进行操作
				if(is_dir($path."\\".$filename)){// 如果读取的某个对象是文件夹，则递归
					$basepath = $basepath.$filename."\\";
					self::addFileToZip($path."\\".$filename, $zip,$basepath);
				}else{ //将文件加入zip对象
					$zip->addFile($path."\\".$filename,$basepath.$filename);
				}
			}
		}
		@closedir($path);
	}
}

?>