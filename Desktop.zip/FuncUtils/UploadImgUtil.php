<?php
namespace FuncUtils;

/**
 * 上传文件/图片工具类
 * @author Administrator
 *
 */
require('../extend/Cos/include.php');
use QCloud\Cos\Api;
use think\facade\Config;

class UploadImgUtil {
	private $rootpath ="";	
	private $compid;
 	
	/**
	 * 初始化文件上传工具类
	 * @param string $compid
	 */
	function __construct($compid)
	{
		$this->compid = $compid;
		$this->rootpath = Config::get('cos.UPLODE');
	}

	
	/**
	 * @return the $rootpath
	 */
	public function getRootpath() {
		return $this->rootpath;
	}
	//上传文单个文件
	/**
	 * 使用网页中的http post方式单文件上传功能
	 * @param string $modulename	当前执行的控制器名称
	 * @param array $exts	上传文件扩展名	如:array('jpg', 'gif', 'png', 'jpeg');
	 * @return 返回值  失败时返回false ,成功时返回info 的格式：
	 *  属性 描述
	 savepath 上传文件的保存路径
	 name 上传文件的原始名称
	 savename 上传文件的保存名称
	 size 上传文件的大小
	 type 上传文件的MIME类型
	 ext 上传文件的后缀类型
	 */
	public function qrcode( $modulename , $exts = array() ,$result) {
// 		$data['image'] = $result;
// 		$srcPath = $data['image']['tmp_name'];
		$bucket = Config::get('cos.BUCKET');
	
		$info = array();
// 		if(in_array(strtolower(substr(strrchr($data['image']['name'], '.'), 1)),$exts)){
				
// 			$namearr = explode(".",$data['image']['name']);
// 			$info['name'] = $data['image']['name'];
// 			$info['type'] = $data['image']['type'];
// 			$info['size'] = $data['image']['size'];
// 			$info['ext'] = end($namearr);
			// 生成上传文件的名称
			$name = $this->getSaveName( time().rand(100, 999) );
			$subName = date('Ymd',time());
// 			$info['name'] = $data['image']['name'];
			$info['savename'] = $name;
			$info['savepath'] = 'tools/'.$modulename."/".$subName.'/';
			$src = $result;
			$dst = $this->rootpath.'tools/'.$modulename."/".$subName."/".$name;
			$sliceSize = intval(Config::get('cos.MAXSIZE')) * 1024 * 1024;
				
			$config = Config::get('cos.CONFIG_INFO');
			$cosApi = new Api($config);
			$ret = $cosApi->upload($bucket, $src, $dst , $bizAttr = null, $sliceSize , $insertOnly = null);
	
			if($ret['code'] == 0){
	
				return  $info;
			} else {
	
				return false;
			}
			// return $ret['data'];
// 		} else {
	
// 			return false;
// 		}
	
	}
	
	//上传文单个文件
	/**
	 * 使用网页中的http post方式单文件上传功能
	 * @param string $modulename	当前执行的控制器名称
	 * @param array $exts	上传文件扩展名	如:array('jpg', 'gif', 'png', 'jpeg');
	 * @return 返回值  失败时返回false ,成功时返回info 的格式：
	 *  属性 描述
		savepath 上传文件的保存路径
		name 上传文件的原始名称
		savename 上传文件的保存名称
		size 上传文件的大小
		type 上传文件的MIME类型
		ext 上传文件的后缀类型
	 */
	public function UploadFileOne( $modulename , $exts = array() ) {
        $data['image'] = $_FILES['inputFile'];
		$srcPath = $data['image']['tmp_name'];
		$bucket = Config::get('cos.BUCKET');

		$info = array();
		if(in_array(strtolower(substr(strrchr($data['image']['name'], '.'), 1)),$exts)){
			
	        $namearr = explode(".",$data['image']['name']);
	        $info['name'] = $data['image']['name'];
	        $info['type'] = $data['image']['type'];
	        $info['size'] = $data['image']['size'];
	        $info['ext'] = end($namearr);
	        // 生成上传文件的名称
	        $name = $this->getSaveName( $data['image'] );
	        $subName = date('Ymd',time());
	        $info['name'] = $data['image']['name'];
	        $info['savename'] = $name;
	        $info['savepath'] = 'tools/'.$modulename."/".$subName.'/';
			$src = $data['image']['tmp_name'];
			$dst = $this->rootpath.'tools/'.$modulename."/".$subName."/".$name;
			$sliceSize = intval(Config::get('cos.MAXSIZE')) * 1024 * 1024;
			
			$config = Config::get('cos.CONFIG_INFO');
			
			$cosApi = new Api($config);
			$ret = $cosApi->upload($bucket, $src, $dst , $bizAttr = null, $sliceSize , $insertOnly = null);

 			if($ret['code'] == 0){

 				return  $info;
 			} else {

				return false;
 			}
			// return $ret['data'];
		} else {

			return false;
		}
		
	}
	
	
	//转存图片
	/**
	 * 使用网页中的http post方式单文件上传功能
	 * @param string $modulename	当前执行的控制器名称
	 * @return 返回值  失败时返回false ,成功时返回info 的格式：
	 *  属性 描述
	 savepath 上传文件的保存路径
	 savename 上传文件的保存名称
	 ext 上传文件的后缀类型
	 $modulename.
	 */
	public function TransferFileOne( $file_src, $modulename ,$img_name, $ext,$exts = array() ) {
		$bucket = Config::get('cos.BUCKET');
	
		$info = array();
			
		// 生成上传文件的名称
		$name = $this->getSaveName( $file_src );
		$subName = date('Ymd',time());
		$info['savename'] = $img_name.'.'.$ext;
		$info['savepath'] = $modulename."/".$subName.'/';
		
		$dst = $this->rootpath.$modulename."/".$subName."/".$img_name.'.'.$ext;
		$sliceSize = intval(Config::get('cos.MAXSIZE')) * 1024 * 1024;
			
		$config = Config::get('cos.CONFIG_INFO');
		$cosApi = new Api($config);
		$ret = $cosApi->upload($bucket, $file_src, $dst , $bizAttr = null, $sliceSize , $insertOnly = null);
		p_file('TransferFileOne TransferFileOne TransferFileOne');
		p_file(json_encode($ret,JSON_UNESCAPED_UNICODE));
		if($ret['code'] == 0){
			return  $info;
		} else {

			return false;
		}
	
	}


	//上传多个文件
	/**
	 * 使用网页中的http post方式多个文件上传功能
	 * @param string $modulename	当前执行的控制器名称
	 * @param array $exts	上传文件扩展名	如:array('jpg', 'gif', 'png', 'jpeg');
	 * @return 返回值  失败时返回false ,成功时返回info 的格式：
	 *  属性 描述
	 savepath 上传文件的保存路径
	 name 上传文件的原始名称
	 savename 上传文件的保存名称
	 size 上传文件的大小
	 type 上传文件的MIME类型
	 ext 上传文件的后缀类型
	 */
	public function  UploadFile( $modulename , $exts = array() ){
		
		/* 逐个检测并上传文件 */
		$info = array();
		$sliceSize = intval(Config::get('cos.MAXSIZE')) * 1024 * 1024;
		$bucket = Config::get('cos.BUCKET');
		$subName = date('Ymd',time());
		$config = Config::get('cos.CONFIG_INFO');
		$cosApi = new Api($config);
		if(function_exists('finfo_open')){
			$finfo   =  finfo_open ( FILEINFO_MIME_TYPE );
		}

		// 对上传文件数组信息处理
		$files   =  $this->dealFiles($_FILES['inputFile']);

		foreach ($files as $key => $file) {
			$list = array();
			$file['name']  = strip_tags($file['name']);
			if(!isset($file['key']))   $file['key']    =   $key;
			/* 通过扩展获取文件类型，可解决FLASH上传$FILES数组返回文件类型错误的问题 */
			if(isset($finfo)){
				$file['type']   =   finfo_file ( $finfo ,  $file['tmp_name'] );
			}
		
			/* 获取上传文件后缀，允许上传无后缀文件 */
			$file['ext']    =   pathinfo($file['name'], PATHINFO_EXTENSION);
			
			$namearr = explode(".",$file['name']);
			
	        $list['name'] = $file['name'];
	        $list['type'] = $file['type'];
	        $list['size'] = $file['size'];
	        $list['ext'] = end($namearr);

	        $list['savepath'] = $this->compid.'/'.$modulename."/".$subName.'/';
			$src = $file['tmp_name'];
			
			$name = $this->getSaveName($file);
			$list['savename'] = $name;
			$dst = $this->rootpath.$this->compid.'/'.$modulename."/".$subName."/".$name;;
			$ret = $cosApi->upload($bucket, $src, $dst , $bizAttr = null, $sliceSize , $insertOnly = null);
			if($ret['code'] == 0){

 				$info[$key] = $list;
 			}
		}
		if( empty($info) ){

			return false;
		} else {

			return $info;
		}
		

	}
	/**
	 * 
	 * @param string $path	上传文件的路径（必须为真实存在的文件）
	 * @param string $modulename	当前执行的控制器名称
	 * @param array $exts	上传文件扩展名	如:array('jpg', 'gif', 'png', 'jpeg');
	 * @return 返回值  失败时返回false ,成功时返回info 的格式：
	 *  属性 描述
		savepath 上传文件的保存路径
		name 上传文件的原始名称
		savename 上传文件的保存名称
		ext 上传文件的后缀类型
	 */
	public function  Upload( $path , $modulename , $exts = array()  ){
		if( is_file($path) ){
			$file['name'] = pathinfo($path)['basename'];
	        $file['type'] = pathinfo($path)['extension'];
	        $file['tmp_name'] = $path;
			$data['image'] = $file;
		} else {

			return false;
		}
		
		$bucket = Config::get('cos.BUCKET');

		$info = array();
		if(in_array(strtolower(substr(strrchr($data['image']['name'], '.'), 1)),$exts)){
			
	        $namearr = explode(".",$data['image']['name']);
	        $info['name'] = $data['image']['name'];
	        $info['ext'] = end($namearr);
	        // 生成上传文件的名称
	        $name = $this->getSaveName( $data['image'] );
	        $subName = date('Ymd',time());
	        $info['name'] = $data['image']['name'];
	        $info['savename'] = $name;
	        $info['savepath'] = $this->compid.'/'.$modulename."/".$subName.'/';
			$src = $data['image']['tmp_name'];
			$dst = $this->rootpath.$this->compid.'/'.$modulename."/".$subName."/".$name;
			$sliceSize = intval(Config::get('cos.MAXSIZE')) * 1024 * 1024;
			
			$config = Config::get('cos.CONFIG_INFO');
			
			$cosApi = new Api($config);
			$ret = $cosApi->upload($bucket, $src, $dst , $bizAttr = null, $sliceSize , $insertOnly = null);
 			if($ret['code'] == 0){

 				return  $info;
 			} else {

				return false;
 			}
			// return $ret['data'];
		} else {

			return false;
		}
	}
	
	
	/**
	 * 将多文件格式转换化为数组
	 */

	private function dealFiles($files) {
		$fileArray  = array();
		$n          = 0;
		//         foreach ($files as $key=>$file){
	
		if(is_array($files['name'])) {
			$keys       =   array_keys($files);
			$count      =   count($files['name']);
	
			for ($i=0; $i<$count; $i++) {
				//                     $fileArray[$n]['key'] = $key;
				foreach ($keys as $_key){
					$fileArray[$n][$_key] = $files[$_key][$i];
				}
				$n++;
			}
		}else{
			$fileArray = $files;
			//                break;
		}
		//         }
		return $fileArray;
	}

	/**
	 * 使用uniqid生成文件13位长度的名称
	 */
	private function getSaveName( $file ){
		// 生成上传文件的名称
		$data['image'] = $file;
	    $namearr = explode(".",$data['image']);
	    $filename = uniqid();
	    $name = $filename.'.'.end($namearr);
	    return $name;
	}
	





	
}


?>