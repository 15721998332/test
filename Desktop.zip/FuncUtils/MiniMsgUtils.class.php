<?php
namespace Common\Lib\FuncUtils;

/**
 * 小程序模板消息的相关业务
 * @author Administrator
 * 
 */
class MiniMsgUtils {

	// 		添加formid
	static public function addMinMsgResource($compid,$vip_id,$resource_data){
		$save_data = array(
			'comp_id'=>$compid,
			'vip_id'=>$vip_id,
			'rel_billtype'=>$resource_data['rel_billtype'],
			'rel_billno'=>$resource_data['rel_billno'],
			'form_id'=>$resource_data['form_id'],
			'ttl_times'=>$resource_data['ttl_times'],
// 			'used_times'=>$resource_data['used_times']
		);
		$ret = M('mini_template_resource')->add($save_data);
		if($ret===false){
			return false;
		}else{
			return true;
		}
	}
	

}

?>