<?php

namespace FuncUtils;

/**
 * 上传文件工具类
 * @author Administrator
 *
 */
class UploadFileUtil {
	private $rootpath ="";	//"./Public/uploads/";
	private $compid;
 	private $errmsg="";	//错误信息
 	
	/**
	 * 初始化文件上传工具类
	 * @param string $compid
	 */
	function __construct($compid)
	{
		$this->compid = $compid;
// 		$this->rootpath = ".".C('TMPL_PARSE_STRING.__UPLOADLOCAL__');
// 		p_file('UploadFileUtil');
// 		p_file($this->rootpath);
// 		p_file(__ROOT__);
		
		$tempdir = getcwd().'/temp/';
		
			
		if (!file_exists($tempdir)){
			mkdir($tempdir,0777,true);
		}
		$this->rootpath = $tempdir;
	}

	
	/**
	 * @return the $rootpath
	 */
	public function getRootpath() {
		return $this->rootpath;
	}

	/**
	 * @return the $errmsg
	 */
	public function getErrmsg() {
		return $this->errmsg;
	}

	/**
	 * 使用网页中的http post方式单文件上传功能
	 * @param string $modulename	当前执行的控制器名称
	 * @param array $exts	上传文件扩展名	如:array('jpg', 'gif', 'png', 'jpeg');
	 * @return 返回值  失败时返回false ,成功时返回info 的格式：
	 *  属性 描述
		key 附件上传的表单名称
		savepath 上传文件的保存路径
		name 上传文件的原始名称
		savename 上传文件的保存名称
		size 上传文件的大小
		type 上传文件的MIME类型
		ext 上传文件的后缀类型
		md5 上传文件的md5哈希验证字符串 仅当hash设置开启后有效
		sha1 上传文件的sha1哈希验证字符串 仅当hash设置开启后有效
	 */
	public function uploadFileOne($modulename,$exts = array())
	{
		$upload = new \Think\Upload();						// 实例化上传类
		$maxsize = getsysparamvalue( "FILEUPLOAD_MAX_SIZE");
		if (!is_numeric($maxsize))
		{
			$maxsize = 20;
		}
		$upload->maxSize   =  intval($maxsize) * 1024 * 1024;		// 设置附件上传大小
		$upload->exts = $exts;	// 设置附件上传类型
		$upload->rootPath =  $this->rootpath;	//根目录
		$upload->savePath  =  $this->compid.'/'.$modulename."/"; // 设置附件上传目录
		$upload->autoSub = true;		//
		$upload->subName = array('date','Ymd');		//子目录格式
		$upload->saveName = array('uniqid','');	//文件名
		
		// 上传文件
		$info = $upload->uploadOne($_FILES['inputFile']);
		if(!$info)// 上传错误提示错误信息
		{
			$this->errmsg = $upload->getError();
			return false;
		}
		else
		{
			$info['rootpath'] = $upload->rootPath;
			return $info;
		}
	}
	
	
	/**
	 * 使用网页中的http post方式多个文件上传功能
	 * @param string $modulename	当前执行的控制器名称
	 * @param array $exts	上传文件扩展名	如:array('jpg', 'gif', 'png', 'jpeg');
	 * @return 返回值  失败时返回false ,成功时返回info 的格式：
	 *  属性 描述
	 key 附件上传的表单名称
	 savepath 上传文件的保存路径
	 name 上传文件的原始名称
	 savename 上传文件的保存名称
	 size 上传文件的大小
	 type 上传文件的MIME类型
	 ext 上传文件的后缀类型
	 md5 上传文件的md5哈希验证字符串 仅当hash设置开启后有效
	 sha1 上传文件的sha1哈希验证字符串 仅当hash设置开启后有效
	 */
	public function uploadMultiFile($modulename,$exts = array())
	{
		$upload = new \Think\Upload();						// 实例化上传类
		$maxsize = getsysparamvalue($this->compid, "FILEUPLOAD_MAX_SIZE");
		if (!is_numeric($maxsize))
		{
			$maxsize = 20;
		}
		$upload->maxSize   =  intval($maxsize) * 1024 * 1024;		// 设置附件上传大小
		$upload->exts = $exts;	// 设置附件上传类型
		$upload->rootPath =  $this->rootpath;	//根目录
		$upload->savePath  =  $this->compid.'/'.$modulename."/"; // 设置附件上传目录
		$upload->autoSub = true;		//
		$upload->subName = array('date','Ymd');		//子目录格式
		$upload->saveName = array('uniqid','');	//文件名
	
		// 上传文件
		$info = $upload->upload($_FILES['inputFile']);
		if(!$info)// 上传错误提示错误信息
		{
			$this->errmsg = $upload->getError();
			return false;
		}
		else
		{
			return $info;
		}
	}	
}

?>