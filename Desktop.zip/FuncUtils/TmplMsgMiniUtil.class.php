<?php
namespace Common\Lib\FuncUtils;

use Common\Lib\WeiXin\WXSdk;
use Common\Lib\FuncUtils\TmplValueBean;
use Common\Lib\WeiXin\WXMinSdk;

/**
 * 模板消息处理的功能类,该类使用前必面初始化
 * @author Administrator
 * 1.checkValid			判断消息模板是否有效
 * 2.sendTemplateMessageByVipid		根据VIPID号发送消息
 * 3.sendTemplateMessageByOpenid		根据OpenID号发送消息
 */
class TmplMsgMiniUtil {
	
	private $compmd5id;		//公司唯一识别符
	private $compid;		//公司号
	private $setupid;		//公众号
	private $templ_id;		//微信中使用模板的唯一ID，每创建一次都不一样,调用接口发送消息时使用该ID
	private $tmpl_num;		//系统中定义的触发模板消息的编号
	private $def_title;		//模板缺省标题
	private $def_remark;	//模板缺省备注
	private $def_url;		//模板缺省URL
	private $minipath;		//模板缺省minipath
	private $isvalid="N";	//模板是否生效使用,为Y时表示可使用
	
	private $keyword1="";	//模板内容参数1
	private $keyword2="";	//模板内容参数2
	private $keyword3="";	//模板内容参数3
	private $keyword4="";	//模板内容参数4
	private $keyword5="";	//模板内容参数5
	
	private $form_id="";
	
	/**
	 * 构造函数,获指定模板信息
	 * @param int $compid	公司ID
	 * @param String $tmplnum  内部模板编号
	 */
	function __construct($compid,$tmplnum)
	{
		//读取配置参数
// 		$vipsetup = M("vip_platform_setup (nolock)")->field("weixinid")->where(array("comp_id"=>$compid,"setup_id"=>$setupid))->find();
// 		$this->compmd5id = $vipsetup["weixinid"];
		$this->compid = $compid;
// 		$this->setupid = $setupid;
		//读取模板配置
		$this->tmpl_num = $tmplnum;
		
		$tmpl = M("mini_msgtemplate t1")
		->join("t_mini_msgtemplate_setup t2 on (t1.tmpl_num = t2.tmpl_num) ")
		->field("t2.tmpl_num,t2.templ_id,t2.used,t2.minipath,t1.fieldslist,t1.fieldsname")
		->where(array("t2.comp_id"=>$compid,"t2.tmpl_num"=>$tmplnum))->find();
		
		p_file('$tmpl='.json_encode($tmpl));
		p_file('$tmpl='.getDbError());
		if ($tmpl)
		{
// 			$this->def_title = $tmpl["title"];
// 			$this->def_remark= $tmpl["remark"];
// 			$this->def_url= $tmpl["url"];
			$this->minipath= $tmpl["minipath"];
			$this->isvalid= $tmpl["used"];
			$this->templ_id =$tmpl["templ_id"];
			$this->fieldslist =$tmpl["fieldslist"];
			$this->fieldsname =$tmpl["fieldsname"];
// 			$this->keyword1 =$tmpl["keyword1_param"];
// 			$this->keyword2 =$tmpl["keyword2_param"];
// 			$this->keyword3 =$tmpl["keyword3_param"];
// 			$this->keyword4 =$tmpl["keyword4_param"];
// 			$this->keyword5 =$tmpl["keyword5_param"];
		}
	}
	
	/**
	 * 判断消息模板是否有效
	 * @param String &$errMsg
	 * @return boolean  true/false
	 */
	public function checkValid(&$errMsg)
	{
		if (empty($this->templ_id))
		{
			$errMsg = "小程序消息模板未创建";
			return false;
		}	
		if (strtoupper($this->isvalid) != "Y")
		{
			$errMsg = "小程序消息模板未使用";
			return false;
		}
		if (empty($this->form_id))
		{
			$errMsg = "formid参数未设置";
			return false;
		}
		return true;
	}
	
	
	public function setFormId($formid)
	{
		$this->form_id = $formid;
	}
	
	public function setMiniPath($minipath)
	{
		$this->minipath = $minipath;
	}
	
	
	/**
	 * 发送模板消息
	 * @param int $compid			公司号
	 * @param int $vsetupid			公众号
	 * @param int $vipid			会员号
	 * @param TmplValueBean $value 	消息内容
	 * @param int  $iMsgid			返回的消息号
	 * @param string $sErrmsg		返回的错误文本
	 * @return 返回 true/false
	 */
// 	public function sendTemplateMessageByVipid($compid,$setupid,$vipid,$value,&$iMsgid,&$sErrmsg)
// 	{
// 		//判断模板是否有效
// 		if (!$this->checkValid($sErrmsg))
// 		{
// 			return false;
// 		}
// 		//读取会员信息
// 		//$vip=M("vip (nolock) ")->field("vip_weixin")->where(array("vip_id"=>$vipid,"comp_id"=>$this->compid))->find();
// 		$vip_weixin = M("vip_weixin (nolock) ")->field("binded,openid")->where(array("vip_id"=>$vipid,"comp_id"=>$compid,"setup_id"=>$setupid))->find();
// 		if (!$vip_weixin || strtoupper($vip_weixin["binded"] != 'Y'))
// 		{
// 			$sErrmsg="会员未绑定微信";
// 			return false;
// 		}
// 		return $this->sendTemplateMessage($vip_weixin["openid"], $value, $iMsgid, $sErrmsg);
// 	}	
	
	
	/**
	 * 发送模板消息
	 * @param int $openid			会员号
	 * @param TmplValueBean $value 	消息内容
	 * @param int  $iMsgid			返回的消息号
	 * @param string $sErrmsg		返回的错误文本
	 * @return 返回 true/false
	 */
	public function sendTemplateMessageByOpenid($openid,$value,&$iMsgid,&$sErrmsg)
	{
		//判断模板是否有效
		if (!$this->checkValid($sErrmsg))
		{
			p_file($sErrmsg);
			return false;
		}
		return $this->sendTemplateMessage($openid, $value, $iMsgid, $sErrmsg);
	}
		
	/**
	 * 发送模板消息
	 * @param int $openid			会员openid
	 * @param TmplValueBean $value 	消息内容
	 * @param int  $iMsgid			返回的消息号
	 * @param string $sErrmsg		返回的错误文本
	 * @return 返回 true/false
	 */
	private function sendTemplateMessage($openid,$value,&$iMsgid,&$sErrmsg)
	{
	
		//组合数据
		$msgdata = array(
				"touser"=>$openid,
				"template_id"=>$this->templ_id,
				"page"=>(empty($this->minipath) || strtolower($this->minipath)== 'null' )? '' : $this->minipath,//不填则不跳转
				"form_id"=>$this->form_id,//提交表单的formid
				"data"=>array(),
// 				"color"=>''
// 				"emphasis_keyword"=>''关键字
		);
		
		$fieldslist_map = explode(',', $this->fieldslist);
		$fieldsname_map = explode(',', $this->fieldsname);
		
		foreach ($fieldslist_map as $k=>$v){
			$send_value = $value[$v];
			if( !empty( $send_value ) ){
				
				$keyname = $v;

				$msgdata["data"]['keyword'.($k+1)]= array("value"=>$send_value,"color"=>"#173177");
					
			}
		}
		
		p_file(json_encode($msgdata,JSON_UNESCAPED_UNICODE));
		p_file($this->compid);
// 		return true;
		$wxMsdk = new WXMinSdk($this->compid);
		$errcode = $wxMsdk->sendMiniTemplateMsg($msgdata, $iMsgid, $sErrmsg);
// 		$wxsdk = new WXSdk($this->compmd5id);
// 		$errcoe = $wxsdk->sendTemplateMessage($this->tmpl_id, $openid, $iMsgid, $sErrmsg,$parammap,$firstdata,$remarkdata,$keynote1,$keynote2,$keynote3,$keynote4,$keynote5,$url,$mini_pagepath,$mini_appid);
// 		if (!empty($sErrmsg))
// 		{
// 			p_file($sErrmsg);
// 		}
		if (empty( $errcode ))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}

?>