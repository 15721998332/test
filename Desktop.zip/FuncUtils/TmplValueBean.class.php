<?php
namespace Common\Lib\FuncUtils;

/*
 * 发送模板消息的值传递结构
 */
class TmplValueBean
{
	private $title;
	private $remark;
	private $keyword1;
	private $keyword2;
	private $keyword3;
	private $keyword4;
	private $keyword5;
	private $url;
	private $minipath;
	private $miniappid;
	/**
	 * @return the $title
	 */
	public function getTitle() {
		return $this->title;
	}

	/**
	 * @return the $remark
	 */
	public function getRemark() {
		return $this->remark;
	}

	/**
	 * @return the $keyword1
	 */
	public function getKeyword1() {
		return $this->keyword1;
	}

	/**
	 * @return the $keyword2
	 */
	public function getKeyword2() {
		return $this->keyword2;
	}

	/**
	 * @return the $keyword3
	 */
	public function getKeyword3() {
		return $this->keyword3;
	}

	/**
	 * @return the $keyword4
	 */
	public function getKeyword4() {
		return $this->keyword4;
	}

	/**
	 * @return the $keyword5
	 */
	public function getKeyword5() {
		return $this->keyword5;
	}
	
	/**
	 * @return the $keyword5
	 */
	public function getUrl() {
		return $this->url;
	}
	
	/**
	 * @return the $keyword5
	 */
	public function getMiniPath() {
		return $this->minipath;
	}
	
	/**
	 * @return the $keyword5
	 */
	public function getMiniAppid() {
		return $this->miniappid;
	}

	/**
	 * @param field_type $title
	 */
	public function setTitle($title) {
		$this->title = $title;
	}

	/**
	 * @param field_type $remark
	 */
	public function setRemark($remark) {
		$this->remark = $remark;
	}

	/**
	 * @param field_type $keyword1
	 */
	public function setKeyword1($keyword1) {
		$this->keyword1 = $keyword1;
	}

	/**
	 * @param field_type $keyword2
	 */
	public function setKeyword2($keyword2) {
		$this->keyword2 = $keyword2;
	}

	/**
	 * @param field_type $keyword3
	 */
	public function setKeyword3($keyword3) {
		$this->keyword3 = $keyword3;
	}

	/**
	 * @param field_type $keyword4
	 */
	public function setKeyword4($keyword4) {
		$this->keyword4 = $keyword4;
	}

	/**
	 * @param field_type $keyword5
	 */
	public function setKeyword5($keyword5) {
		$this->keyword5 = $keyword5;
	}

	/**
	 * @return the $keyword5
	 */
	public function setUrl($url) {
		$this->url = $url;
	}
	
	/**
	 * @return the $keyword5
	 */
	public function setMiniPath($minipath) {
		$this->minipath = $minipath;
	}
	

	/**
	 * @return the $keyword5
	 */
	public function setMiniAppid($miniappid) {
		$this->miniappid = $miniappid;
	}
	
	
}

?>