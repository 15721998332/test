<?php
namespace FuncUtils;

/**
 * Http/Https相关工具类
 * @author Administrator
 *
 */
class HttpUtil {
	
	/**
	 * 使用POST方法调用
	 * @param String $url
	 * @param array $data
	 */
	public static function post($url,$data)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);    // 要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_HEADER, 0); 			// 不要http header 加快效率
		//curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		//指定POST
		curl_setopt($ch, CURLOPT_POST, 1);
		// post的变量
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		
		curl_setopt($ch, CURLOPT_TIMEOUT, 5);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
		
		$output = curl_exec($ch);
		if (curl_errno($ch)) {
			$errinfo = curl_error($ch);
			//echo $errinfo;
			p_file('curl_error=='.$url.$errinfo);
		}		
		curl_close($ch);
		return $output;					
	} 
	
	/**
	 * 使用Https POST方法调用
	 * @param String $url
	 * @param array $data
	 */
	public static function https_post($url,$data,$curl_type)
	{
		if(empty($curl_type)){
			$curl_type=array('Content-Type: multipart/form-data');
		}
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_HEADER, 0); 			// 不要http header 加快效率
		curl_setopt($ch, CURLOPT_HTTPHEADER, $curl_type);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
		curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);	
		curl_setopt($ch, CURLOPT_TIMEOUT, 5);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
		$tmpInfo = curl_exec($ch);
		if (curl_errno($ch)) {
			$errinfo = curl_error($ch);
		     //echo $errinfo;
		     p_file('curl_error=='.$url.$errinfo);
		}
		
		curl_close($ch);
		
		return $tmpInfo;
		
	}
		
	/**
	 * http get 方式发送数据到指定地址
	 * @param unknown $url
	 * @return mixed
	 */
	public static function get($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);    // 要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_HEADER, 0); // 不要http header 加快效率
		//curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		curl_setopt($ch, CURLOPT_TIMEOUT, 5);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
		
		$output = curl_exec($ch);
		if (curl_errno($ch)) {
			$errinfo = curl_error($ch);
			//echo $errinfo;
			p_file('curl_error=='.$url.$errinfo);
		}
		curl_close($ch);
		return $output;	
	}
	
	/**
	 * https get方式发送数据到指定地址
	 * @param unknown $url
	 * @return mixed
	 */
	public static function https_get($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);    // 要求结果为字符串且输出到屏幕上
		curl_setopt($ch, CURLOPT_HEADER, 0); // 不要http header 加快效率
		//curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
		curl_setopt($ch, CURLOPT_TIMEOUT, 5);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);    // https请求 不验证证书和hosts
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		
		$output = curl_exec($ch);
		
		if (curl_errno($ch)) {
			$errinfo = curl_error($ch);
			//echo $errinfo;
			p_file('curl_error=='.$url.$errinfo);
		}
				
		curl_close($ch);
		return $output;		
	}

	/**
	 * POST 请求(包括http与https)
	 * @param string $url
	 * @param array $param
	 * @param boolean $post_file 是否文件上传
	 * @return string content
	 */
	public static function http_post($url,$param,$post_file=false){
		$oCurl = curl_init();
// 		curl_setopt ( $oCurl, CURLOPT_SAFE_UPLOAD, false);
		if(stripos($url,"https://")!==FALSE){
			curl_setopt($oCurl, CURLOPT_SSL_VERIFYPEER, FALSE);
			curl_setopt($oCurl, CURLOPT_SSL_VERIFYHOST, false);
			curl_setopt($oCurl, CURLOPT_SSLVERSION, 1); //CURL_SSLVERSION_TLSv1
		}
// 		if (is_string($param) || $post_file) {
// 			$strPOST = $param;
// 		} else {
// 			$aPOST = array();
// 			foreach($param as $key=>$val){
// 				$aPOST[] = $key."=".urlencode($val);
// 			}
// 			$strPOST =  join("&", $aPOST);
// 		}
		
		p_file(json_encode($post_file,JSON_UNESCAPED_UNICODE));
		
		curl_setopt($oCurl, CURLOPT_URL, $url);
		curl_setopt($oCurl, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt($oCurl, CURLOPT_POST,true);
		curl_setopt($oCurl, CURLOPT_HEADER, 0); 			// 不要http header 加快效率
		curl_setopt($oCurl, CURLOPT_TIMEOUT, 30);
		curl_setopt($oCurl, CURLOPT_CONNECTTIMEOUT, 30);
// 		curl_setopt($oCurl, CURLOPT_POSTFIELDS,$strPOST);
		curl_setopt($oCurl, CURLOPT_POSTFIELDS,$param);
		$sContent = curl_exec($oCurl);
		$aStatus = curl_getinfo($oCurl);
		if(curl_errno($oCurl))
		{
			p_file('curl_error=='.curl_error($oCurl));
		}
		curl_close($oCurl);
		if(intval($aStatus["http_code"])==200){
			return $sContent;
		}else{
			p_file('上传文件请求状态$aStatus='.json_encode($aStatus));
			return false;
		}
	}
	
	
	/**
	 * POST 请求(包括http与https)
	 * @param string $url
	 * @param array $param
	 * @param boolean $post_file 是否文件上传
	 * @return string content
	 */
// 	public static function http_post($url,$param,$post_file=false){
// 		$oCurl = curl_init();
// 		curl_setopt ( $oCurl, CURLOPT_SAFE_UPLOAD, false);
// 		if(stripos($url,"https://")!==FALSE){
// 			curl_setopt($oCurl, CURLOPT_SSL_VERIFYPEER, FALSE);
// 			curl_setopt($oCurl, CURLOPT_SSL_VERIFYHOST, false);
// 			curl_setopt($oCurl, CURLOPT_SSLVERSION, 1); //CURL_SSLVERSION_TLSv1
// 		}
// 		// 		if (is_string($param) || $post_file) {
// 		// 			$strPOST = $param;
// 		// 		} else {
// 		// 			$aPOST = array();
// 		// 			foreach($param as $key=>$val){
// 		// 				$aPOST[] = $key."=".urlencode($val);
// 		// 			}
// 		// 			$strPOST =  join("&", $aPOST);
// 		// 		}
	
	
	
// 		curl_setopt($oCurl, CURLOPT_URL, $url);
// 		curl_setopt($oCurl, CURLOPT_RETURNTRANSFER, 1 );
// 		curl_setopt($oCurl, CURLOPT_POST,true);
// 		curl_setopt($oCurl, CURLOPT_HEADER, 0); 			// 不要http header 加快效率
// 		curl_setopt($oCurl, CURLOPT_TIMEOUT, 30);
// 		curl_setopt($oCurl, CURLOPT_CONNECTTIMEOUT, 30);
// 		// 		curl_setopt($oCurl, CURLOPT_POSTFIELDS,$strPOST);
// 		$sContent = curl_exec($oCurl);
// 		$aStatus = curl_getinfo($oCurl);
// 		if(curl_errno($oCurl))
// 		{
// 			p_file('curl_error=='.curl_error($oCurl));
// 		}
// 		curl_close($oCurl);
// 		if(intval($aStatus["http_code"])==200){
// 			return $sContent;
// 		}else{
// 			p_file('上传文件请求状态$aStatus='.json_encode($aStatus));
// 			return false;
// 		}
// 	}
	
}

?>