<?php
namespace Common\Lib\FuncUtils;

use Common\Lib\WeiXin\WXSdk;
use Common\Lib\FuncUtils\TmplValueBean;

/**
 * 模板消息处理的功能类,该类使用前必面初始化
 * @author Administrator
 * 1.checkValid			判断消息模板是否有效
 * 2.sendTemplateMessageByVipid		根据VIPID号发送消息
 * 3.sendTemplateMessageByOpenid		根据OpenID号发送消息
 */
class TmplMsgUtil {
	
	private $compmd5id;		//公司唯一识别符
	private $compid;		//公司号
	private $setupid;		//公众号
	private $tmpl_id;		//微信中使用模板的唯一ID，每创建一次都不一样,调用接口发送消息时使用该ID
	private $tmpl_num;		//系统中定义的触发模板消息的编号
	private $def_title;		//模板缺省标题
	private $def_remark;	//模板缺省备注
	private $def_url;		//模板缺省URL
	private $minipath;		//模板缺省minipath
	private $isvalid="N";	//模板是否生效使用,为Y时表示可使用
	
	private $keyword1="";	//模板内容参数1
	private $keyword2="";	//模板内容参数2
	private $keyword3="";	//模板内容参数3
	private $keyword4="";	//模板内容参数4
	private $keyword5="";	//模板内容参数5
	
	/**
	 * 构造函数,获指定模板信息
	 * @param int $compid	公司ID
	 * @param String $tmplnum  内部模板编号
	 */
	function __construct($compid,$setupid,$tmplnum)
	{
		//读取配置参数
		$vipsetup = M("vip_platform_setup (nolock)")->field("weixinid")->where(array("comp_id"=>$compid,"setup_id"=>$setupid))->find();
		$this->compmd5id = $vipsetup["weixinid"];
		$this->compid = $compid;
		$this->setupid = $setupid;
// 		p_file('TmplMsgUtil  compmd5id=='.$this->compmd5id);
		//读取模板配置
		$this->tmpl_num = $tmplnum;
		$tmpl = M("wx_template t1")->join("t_wx_template_setup t2 on (t1.tmpl_num = t2.tmpl_num) ")->field("t2.tmpl_num,t2.tmpl_id,t2.title,t2.url,t2.remark,t2.isuse,t2.mini_pagepath ,t1.keyword1_param,t1.keyword2_param,t1.keyword3_param,t1.keyword4_param,t1.keyword5_param")->where(array("t2.comp_id"=>$compid,"t2.tmpl_num"=>$tmplnum,"t2.setup_id"=>$setupid))->find();
// 		p_file('$tmpl='.json_encode($tmpl));
		if ($tmpl)
		{
			$this->def_title = $tmpl["title"];
			$this->def_remark= $tmpl["remark"];
			$this->def_url= $tmpl["url"];
			$this->minipath= $tmpl["mini_pagepath"];
			$this->isvalid= $tmpl["isuse"];
			$this->tmpl_id =$tmpl["tmpl_id"];
			$this->keyword1 =$tmpl["keyword1_param"];
			$this->keyword2 =$tmpl["keyword2_param"];
			$this->keyword3 =$tmpl["keyword3_param"];
			$this->keyword4 =$tmpl["keyword4_param"];
			$this->keyword5 =$tmpl["keyword5_param"];
		}
	}
	
	/**
	 * 判断消息模板是否有效
	 * @param String &$errMsg
	 * @return boolean  true/false
	 */
	public function checkValid(&$errMsg)
	{
		if (empty($this->tmpl_id))
		{
			$errMsg = "消息模板未创建";
			return false;
		}	
		if (strtoupper($this->isvalid) != "Y")
		{
			$errMsg = "消息模板未使用";
			return false;
		}
		return true;
	}
	
	
	/**
	 * 发送模板消息
	 * @param int $compid			公司号
	 * @param int $vsetupid			公众号
	 * @param int $vipid			会员号
	 * @param TmplValueBean $value 	消息内容
	 * @param int  $iMsgid			返回的消息号
	 * @param string $sErrmsg		返回的错误文本
	 * @return 返回 true/false
	 */
	public function sendTemplateMessageByVipid($vipid,$value,&$iMsgid,&$sErrmsg)
	{
		//判断模板是否有效
		if (!$this->checkValid($sErrmsg))
		{
			return false;
		}
		//读取会员信息
		//$vip=M("vip (nolock) ")->field("vip_weixin")->where(array("vip_id"=>$vipid,"comp_id"=>$this->compid))->find();
		$vip_weixin = M("vip_weixin ")->field("binded,openid")->where(array("vip_id"=>$vipid,"comp_id"=>$this->compid,"setup_id"=>$this->setupid))->find();
		if (!$vip_weixin || strtoupper($vip_weixin["binded"] != 'Y'))
		{
			$sErrmsg="会员未绑定微信";
			return false;
		}
		return $this->sendTemplateMessage($vip_weixin["openid"], $value, $iMsgid, $sErrmsg);
	}	
	
	
	/**
	 * 发送模板消息
	 * @param int $openid			会员号
	 * @param TmplValueBean $value 	消息内容
	 * @param int  $iMsgid			返回的消息号
	 * @param string $sErrmsg		返回的错误文本
	 * @return 返回 true/false
	 */
	public function sendTemplateMessageByOpenid($openid,$value,&$iMsgid,&$sErrmsg)
	{
		//判断模板是否有效
		if (!$this->checkValid($sErrmsg))
		{
			return false;
		}
		return $this->sendTemplateMessage($openid, $value, $iMsgid, $sErrmsg);
	}
		
	/**
	 * 发送模板消息
	 * @param int $openid			会员openid
	 * @param TmplValueBean $value 	消息内容
	 * @param int  $iMsgid			返回的消息号
	 * @param string $sErrmsg		返回的错误文本
	 * @return 返回 true/false
	 */
	private function sendTemplateMessage($openid,$value,&$iMsgid,&$sErrmsg)
	{
		//判断模板是否有效
		if (!$this->checkValid($sErrmsg))
		{
			return false;
		}
		//参数对应
		$parammap = array("first"=>"first","remark"=>"remark");
		if (!empty($this->keyword1))
		{
			$parammap["keynote1"]=$this->keyword1;
		}
		if (!empty($this->keyword2))
		{
			$parammap["keynote2"]=$this->keyword2;
		}
		if (!empty($this->keyword3) || $this->keyword3 === 0)
		{
			$parammap["keynote3"]=$this->keyword3;
		}
		if (!empty($this->keyword4) || $this->keyword4 === 0)
		{
			$parammap["keynote4"]=$this->keyword4;
		}
		if (!empty($this->keyword5))
		{
			$parammap["keynote5"]=$this->keyword5;
		}
		
		//发送消息
		$firstdata=$this->def_title;
		if (empty($firstdata))
		{
			$firstdata=$value->getTitle();	
		}
		$remarkdata=$value->getRemark();
		if (empty($remarkdata))
		{
			$remarkdata=$this->def_remark;
		}				
		$keynote1=$value->getKeyword1();
		$keynote2=$value->getKeyword2();
		$keynote3=$value->getKeyword3();
		$keynote4=$value->getKeyword4();
		$keynote5=$value->getKeyword5();
		
		
		$mini_appid = $value->getMiniAppid();

		$arr_tmpl = explode("_",$this->tmpl_num);
		if(is_array($arr_tmpl) && $arr_tmpl[0] == "refund")//退款类型消息
		{
			$url = $value->getUrl();
			$mini_pagepath = $value->getMiniPath();
		}
		else
		{
			
			$url=$this->def_url;
			$mini_pagepath = $this->minipath;
			
			if(empty($url)){
				$url = $value->getUrl();
			}
			if(empty($mini_pagepath)){
				$mini_pagepath = $value->getMiniPath();
			}
		}

		
// 		$url = $value->getUrl();
// 		$mini_pagepath = $value->getMiniPath();
// 		if(empty($url))
// 		{
// 			$url=$this->def_url;
// 		}
// 		if(empty($mini_pagepath))
// 		{
// 			$mini_pagepath = $this->minipath;
// 		}
		
		
		$wxsdk = new WXSdk($this->compmd5id);
		$errcoe = $wxsdk->sendTemplateMessage($this->tmpl_id, $openid, $iMsgid, $sErrmsg,$parammap,$firstdata,$remarkdata,$keynote1,$keynote2,$keynote3,$keynote4,$keynote5,$url,$mini_pagepath,$mini_appid);
		if (!empty($sErrmsg))
		{
			p_file($sErrmsg);
		}
		if (empty($errcoe))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	//退款业务发送模板消息时，读取setup_id
	public static function getSetupIdByShopid($compid,$shopid,$vipid)
	{
		p_file('getSetupIdByShopid 646456');
		$setupid = M("vip_platform_setup")->where(array("comp_id"=>$compid,"mall_shopid"=>$shopid))->getField("setup_id");
		if(!empty($setupid))
		{
			return $setupid;
		}
		else
		{
			if(empty($vipid))
			{
				p_file('getSetupIdByShopid  $vipid不在');
			}
			$setupid = M("vip")->where(array("comp_id"=>$compid,"vip_id"=>$vipid))->getField("setup_id");
			return $setupid;
		}
	}
}

?>