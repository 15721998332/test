<?php
return array(
	
		//腾讯云配置
		'BUCKET' => 'demo', //存储桶（测试用）
		'CONFIG_INFO' => array(
				'app_id' => '1256311631',
				'secret_id' => 'AKIDa5ThjdDErIZfUDr9LNvMk1ACJMEvrq00',
				'secret_key' => 'yoW7h8NQIxRjuuUgleOwIVYP5axEJH6j',
				'region' => 'gz',
				'timeout' => 60
		),
		'UPLODE' => 'Public/uploads/',
		'MAXSIZE' => 3,//上传文件的最大值 如 3GB	
);
?>