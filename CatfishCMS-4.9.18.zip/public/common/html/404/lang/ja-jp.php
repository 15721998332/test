<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'You visit the page out to play!' => 'あなたは、ページが遊びに行ってきました訪問します！',
    'The page does not exist, please click the link at the bottom of the page to return' => 'あなたが存在しないページを訪問、返すようにページリンクの下をクリックしてください',
    'Access error' => 'アクセスエラー',
    'Return to the home page' => 'ホームに戻る'
];