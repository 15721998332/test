/**
 * Created by A.J on 2016/10/16.
 */
$(document).ready(function(){
    $( "#datepicker" ).datepicker({
        changeMonth: true,
        changeYear: true
    });
});