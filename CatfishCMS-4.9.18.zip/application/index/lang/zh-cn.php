<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/11/22
 */
return [
    'Article list' => '文章列表',
    'No search found' => '没有找到搜索内容',
    'Search' => '搜索',
    'Message content must be filled out' => '留言内容必须填写',
    'The e-mail format is incorrect' => '邮箱格式错误',
    'Sign up' => '注册',
    'Log in' => '登录',
    'User center' => '用户中心',
    'Sign out' => '退出',
    'secrecy' => '保密',
    'male' => '男',
    'female' => '女',
    'Related categories' => '相关分类',
    'Articles' => '文章'
];